﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Matrice
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox1.Visible = false;
            textBox2.Visible = false;
            textBox3.Visible = false;
            textBox4.Visible = false;
            textBox5.Visible = false;
            textBox6.Visible = false;
            textBox7.Visible = false;
            textBox8.Visible = false;
            textBox9.Visible = false;
            textBox10.Visible = false;
            textBox11.Visible = false;
            textBox12.Visible = false;
            textBox13.Visible = false;
            textBox14.Visible = false;
            textBox15.Visible = false;
            textBox16.Visible = false;
            textBox17.Visible = false;
            textBox18.Visible = false;
            textBox19.Visible = false;
            textBox20.Visible = false;
            textBox21.Visible = false;
            textBox22.Visible = false;
            textBox23.Visible = false;
            textBox24.Visible = false;
            textBox25.Visible = false;
            textBox26.Visible = false;
            textBox27.Visible = false;
            textBox28.Visible = false;
            textBox29.Visible = false;
            textBox30.Visible = false;
            textBox31.Visible = false;
            textBox32.Visible = false;
            textBox33.Visible = false;
            textBox34.Visible = false;
            button1.Visible = false;
            button2.Visible = false;
            button4.Visible = false;
            button5.Visible = false;
            button6.Visible = false;
            button7.Visible = false;
            button8.Visible = false;
            button9.Visible = false;
            button10.Visible = false;
            numericUpDown1.Visible = false;
            numericUpDown2.Visible = false;
            numericUpDown3.Visible = false;
            numericUpDown4.Visible = false;
            label1.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label6.Visible = false;
            label7.Visible = false;
            label8.Visible = false;
            label9.Visible = false;
            label10.Visible = false;
            label11.Visible = false;
            label12.Visible = false;
            label13.Visible = false;
            label14.Visible = false;
            label15.Visible = false;
            label16.Visible = false;
            label17.Visible = false;
            label18.Visible = false;
            label19.Visible = false;
            label20.Visible = false;
            label21.Visible = false;
            label22.Visible = false;
            label23.Visible = false;
            label24.Visible = false;
            label25.Visible = false;
            label26.Visible = false;
            label27.Visible = false;
            label28.Visible = false;
            label29.Visible = false;
            zadatakToolStripMenuItem.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label22.Visible = false;
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            textBox9.Text = "";
            textBox10.Text = "";
            textBox11.Text = "";
            textBox12.Text = "";
            textBox13.Text = "";
            textBox14.Text = "";
            textBox15.Text = "";
            textBox16.Text = "";
            button9.Visible = false;
            button10.Visible = false;
            label24.Visible = true;
            label27.Visible = false;
            label28.Visible = false;
            if (numericUpDown1.Value == 2 && numericUpDown2.Value == 2)
            {
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = false;
                textBox4.Visible = false;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = false;
                textBox8.Visible = false;
                textBox9.Visible = false;
                textBox10.Visible = false;
                textBox11.Visible = false;
                textBox12.Visible = false;
                textBox13.Visible = false;
                textBox14.Visible = false;
                textBox15.Visible = false;
                textBox16.Visible = false;
                button9.Visible = true;
                button10.Visible = true;
            }
            else if (numericUpDown1.Value == 3 && numericUpDown2.Value == 2)
            {
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = false;
                textBox4.Visible = false;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = false;
                textBox8.Visible = false;
                textBox9.Visible = true;
                textBox10.Visible = true;
                textBox11.Visible = false;
                textBox12.Visible = false;
                textBox13.Visible = false;
                textBox14.Visible = false;
                textBox15.Visible = false;
                textBox16.Visible = false;
            }
            else if (numericUpDown1.Value == 4 && numericUpDown2.Value == 2)
            {
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = false;
                textBox4.Visible = false;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = false;
                textBox8.Visible = false;
                textBox9.Visible = true;
                textBox10.Visible = true;
                textBox11.Visible = false;
                textBox12.Visible = false;
                textBox13.Visible = true;
                textBox14.Visible = true;
                textBox15.Visible = false;
                textBox16.Visible = false;
            }
            else if (numericUpDown1.Value == 2 && numericUpDown2.Value == 3)
            {
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = false;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;
                textBox8.Visible = false;
                textBox9.Visible = false;
                textBox10.Visible = false;
                textBox11.Visible = false;
                textBox12.Visible = false;
                textBox13.Visible = false;
                textBox14.Visible = false;
                textBox15.Visible = false;
                textBox16.Visible = false;
            }
            else if (numericUpDown1.Value == 2 && numericUpDown2.Value == 4)
            {
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = true;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;
                textBox8.Visible = true;
                textBox9.Visible = false;
                textBox10.Visible = false;
                textBox11.Visible = false;
                textBox12.Visible = false;
                textBox13.Visible = false;
                textBox14.Visible = false;
                textBox15.Visible = false;
                textBox16.Visible = false;
            }
            else if (numericUpDown1.Value == 3 && numericUpDown2.Value == 4)
            {
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = true;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;
                textBox8.Visible = true;
                textBox9.Visible = true;
                textBox10.Visible = true;
                textBox11.Visible = true;
                textBox12.Visible = true;
                textBox13.Visible = false;
                textBox14.Visible = false;
                textBox15.Visible = false;
                textBox16.Visible = false;
            }
            else if (numericUpDown1.Value == 4 && numericUpDown2.Value == 3)
            {
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = false;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;
                textBox8.Visible = false;
                textBox9.Visible = true;
                textBox10.Visible = true;
                textBox11.Visible = true;
                textBox12.Visible = false;
                textBox13.Visible = true;
                textBox14.Visible = true;
                textBox15.Visible = true;
                textBox16.Visible = false;
            }
            else if (numericUpDown1.Value == 3 && numericUpDown2.Value == 3)
            {
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = false;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;
                textBox8.Visible = false;
                textBox9.Visible = true;
                textBox10.Visible = true;
                textBox11.Visible = true;
                textBox12.Visible = false;
                textBox13.Visible = false;
                textBox14.Visible = false;
                textBox15.Visible = false;
                textBox16.Visible = false;
                button9.Visible = true;
                button10.Visible = true;
            }
            else if (numericUpDown1.Value == 4 && numericUpDown2.Value == 4)
            {
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = true;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;
                textBox8.Visible = true;
                textBox9.Visible = true;
                textBox10.Visible = true;
                textBox11.Visible = true;
                textBox12.Visible = true;
                textBox13.Visible = true;
                textBox14.Visible = true;
                textBox15.Visible = true;
                textBox16.Visible = true;
                button9.Visible = true;
                button10.Visible = true;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (numericUpDown5.Value == 1)
            {
                label5.Visible = false;
                button1.Visible = true;
                numericUpDown1.Visible = true;
                numericUpDown2.Visible = true;
                label1.Visible = true;
                numericUpDown5.Visible = false;
                button3.Visible = false;
                label3.Visible = true;
            }
            if (numericUpDown5.Value == 2)
            {
                label5.Visible = false;
                numericUpDown1.Visible = true;
                numericUpDown2.Visible = true;
                label1.Visible = true;
                button2.Visible = true;
                numericUpDown3.Visible = true;
                numericUpDown4.Visible = true;
                label2.Visible = true;
                numericUpDown5.Visible = false;
                button3.Visible = false;
                label3.Visible = true;
                label4.Visible = true;
            }
            zadatakToolStripMenuItem.Visible = true;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            label6.Visible = false;
            label7.Visible = false;
            label8.Visible = false;
            label9.Visible = false;
            label10.Visible = false;
            label11.Visible = false;
            label12.Visible = false;
            label13.Visible = false;
            label14.Visible = false;
            label15.Visible = false;
            label16.Visible = false;
            label17.Visible = false;
            label18.Visible = false;
            label19.Visible = false;
            label20.Visible = false;
            label21.Visible = false;
            label22.Visible = false;
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            textBox9.Text = "";
            textBox10.Text = "";
            textBox11.Text = "";
            textBox12.Text = "";
            textBox13.Text = "";
            textBox14.Text = "";
            textBox15.Text = "";
            textBox16.Text = "";
            if (numericUpDown1.Value == 2 && numericUpDown2.Value == 2)
            {
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = false;
                textBox4.Visible = false;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = false;
                textBox8.Visible = false;
                textBox9.Visible = false;
                textBox10.Visible = false;
                textBox11.Visible = false;
                textBox12.Visible = false;
                textBox13.Visible = false;
                textBox14.Visible = false;
                textBox15.Visible = false;
                textBox16.Visible = false;
            }
            else if (numericUpDown1.Value == 3 && numericUpDown2.Value == 2)
            {
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = false;
                textBox4.Visible = false;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = false;
                textBox8.Visible = false;
                textBox9.Visible = true;
                textBox10.Visible = true;
                textBox11.Visible = false;
                textBox12.Visible = false;
                textBox13.Visible = false;
                textBox14.Visible = false;
                textBox15.Visible = false;
                textBox16.Visible = false;
            }
            else if (numericUpDown1.Value == 4 && numericUpDown2.Value == 2)
            {
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = false;
                textBox4.Visible = false;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = false;
                textBox8.Visible = false;
                textBox9.Visible = true;
                textBox10.Visible = true;
                textBox11.Visible = false;
                textBox12.Visible = false;
                textBox13.Visible = true;
                textBox14.Visible = true;
                textBox15.Visible = false;
                textBox16.Visible = false;
            }
            else if (numericUpDown1.Value == 2 && numericUpDown2.Value == 3)
            {
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = false;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;
                textBox8.Visible = false;
                textBox9.Visible = false;
                textBox10.Visible = false;
                textBox11.Visible = false;
                textBox12.Visible = false;
                textBox13.Visible = false;
                textBox14.Visible = false;
                textBox15.Visible = false;
                textBox16.Visible = false;
            }
            else if (numericUpDown1.Value == 2 && numericUpDown2.Value == 4)
            {
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = true;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;
                textBox8.Visible = true;
                textBox9.Visible = false;
                textBox10.Visible = false;
                textBox11.Visible = false;
                textBox12.Visible = false;
                textBox13.Visible = false;
                textBox14.Visible = false;
                textBox15.Visible = false;
                textBox16.Visible = false;
            }
            else if (numericUpDown1.Value == 3 && numericUpDown2.Value == 4)
            {
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = true;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;
                textBox8.Visible = true;
                textBox9.Visible = true;
                textBox10.Visible = true;
                textBox11.Visible = true;
                textBox12.Visible = true;
                textBox13.Visible = false;
                textBox14.Visible = false;
                textBox15.Visible = false;
                textBox16.Visible = false;
            }
            else if (numericUpDown1.Value == 4 && numericUpDown2.Value == 3)
            {
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = false;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;
                textBox8.Visible = false;
                textBox9.Visible = true;
                textBox10.Visible = true;
                textBox11.Visible = true;
                textBox12.Visible = false;
                textBox13.Visible = true;
                textBox14.Visible = true;
                textBox15.Visible = true;
                textBox16.Visible = false;
            }
            else if (numericUpDown1.Value == 3 && numericUpDown2.Value == 3)
            {
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = false;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;
                textBox8.Visible = false;
                textBox9.Visible = true;
                textBox10.Visible = true;
                textBox11.Visible = true;
                textBox12.Visible = false;
                textBox13.Visible = false;
                textBox14.Visible = false;
                textBox15.Visible = false;
                textBox16.Visible = false;
            }
            else if (numericUpDown1.Value == 4 && numericUpDown2.Value == 4)
            {
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = true;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;
                textBox8.Visible = true;
                textBox9.Visible = true;
                textBox10.Visible = true;
                textBox11.Visible = true;
                textBox12.Visible = true;
                textBox13.Visible = true;
                textBox14.Visible = true;
                textBox15.Visible = true;
                textBox16.Visible = true;
            }
            textBox17.Text = "";
            textBox18.Text = "";
            textBox19.Text = "";
            textBox20.Text = "";
            textBox21.Text = "";
            textBox22.Text = "";
            textBox23.Text = "";
            textBox24.Text = "";
            textBox25.Text = "";
            textBox26.Text = "";
            textBox27.Text = "";
            textBox28.Text = "";
            textBox29.Text = "";
            textBox30.Text = "";
            textBox31.Text = "";
            textBox32.Text = "";
            if (numericUpDown3.Value == 2 && numericUpDown4.Value == 2)
            {
                textBox32.Visible = true;
                textBox31.Visible = true;
                textBox30.Visible = false;
                textBox29.Visible = false;
                textBox28.Visible = true;
                textBox27.Visible = true;
                textBox26.Visible = false;
                textBox25.Visible = false;
                textBox24.Visible = false;
                textBox23.Visible = false;
                textBox22.Visible = false;
                textBox21.Visible = false;
                textBox20.Visible = false;
                textBox19.Visible = false;
                textBox18.Visible = false;
                textBox17.Visible = false;
            }
            else if (numericUpDown3.Value == 3 && numericUpDown4.Value == 2)
            {
                textBox32.Visible = true;
                textBox31.Visible = true;
                textBox30.Visible = false;
                textBox29.Visible = false;
                textBox28.Visible = true;
                textBox27.Visible = true;
                textBox26.Visible = false;
                textBox25.Visible = false;
                textBox24.Visible = true;
                textBox23.Visible = true;
                textBox22.Visible = false;
                textBox21.Visible = false;
                textBox20.Visible = false;
                textBox19.Visible = false;
                textBox18.Visible = false;
                textBox17.Visible = false;
            }
            else if (numericUpDown3.Value == 4 && numericUpDown4.Value == 2)
            {
                textBox32.Visible = true;
                textBox31.Visible = true;
                textBox30.Visible = false;
                textBox29.Visible = false;
                textBox28.Visible = true;
                textBox27.Visible = true;
                textBox26.Visible = false;
                textBox25.Visible = false;
                textBox24.Visible = true;
                textBox23.Visible = true;
                textBox22.Visible = false;
                textBox21.Visible = false;
                textBox20.Visible = true;
                textBox19.Visible = true;
                textBox18.Visible = false;
                textBox17.Visible = false;
            }
            else if (numericUpDown3.Value == 2 && numericUpDown4.Value == 3)
            {
                textBox32.Visible = true;
                textBox31.Visible = true;
                textBox30.Visible = true;
                textBox29.Visible = false;
                textBox28.Visible = true;
                textBox27.Visible = true;
                textBox26.Visible = true;
                textBox25.Visible = false;
                textBox24.Visible = false;
                textBox23.Visible = false;
                textBox22.Visible = false;
                textBox21.Visible = false;
                textBox20.Visible = false;
                textBox19.Visible = false;
                textBox18.Visible = false;
                textBox17.Visible = false;
            }
            else if (numericUpDown3.Value == 2 && numericUpDown4.Value == 4)
            {
                textBox32.Visible = true;
                textBox31.Visible = true;
                textBox30.Visible = true;
                textBox29.Visible = true;
                textBox28.Visible = true;
                textBox27.Visible = true;
                textBox26.Visible = true;
                textBox25.Visible = true;
                textBox24.Visible = false;
                textBox23.Visible = false;
                textBox22.Visible = false;
                textBox21.Visible = false;
                textBox20.Visible = false;
                textBox19.Visible = false;
                textBox18.Visible = false;
                textBox17.Visible = false;
            }
            else if (numericUpDown3.Value == 3 && numericUpDown4.Value == 4)
            {
                textBox32.Visible = true;
                textBox31.Visible = true;
                textBox30.Visible = true;
                textBox29.Visible = true;
                textBox28.Visible = true;
                textBox27.Visible = true;
                textBox26.Visible = true;
                textBox25.Visible = true;
                textBox24.Visible = true;
                textBox23.Visible = true;
                textBox22.Visible = true;
                textBox21.Visible = true;
                textBox20.Visible = false;
                textBox19.Visible = false;
                textBox18.Visible = false;
                textBox17.Visible = false;
            }
            else if (numericUpDown3.Value == 4 && numericUpDown4.Value == 3)
            {
                textBox32.Visible = true;
                textBox31.Visible = true;
                textBox30.Visible = true;
                textBox29.Visible = false;
                textBox28.Visible = true;
                textBox27.Visible = true;
                textBox26.Visible = true;
                textBox25.Visible = false;
                textBox24.Visible = true;
                textBox23.Visible = true;
                textBox22.Visible = true;
                textBox21.Visible = false;
                textBox20.Visible = true;
                textBox19.Visible = true;
                textBox18.Visible = true;
                textBox17.Visible = false;
            }
            else if (numericUpDown3.Value == 3 && numericUpDown4.Value == 3)
            {
                textBox32.Visible = true;
                textBox31.Visible = true;
                textBox30.Visible = true;
                textBox29.Visible = false;
                textBox28.Visible = true;
                textBox27.Visible = true;
                textBox26.Visible = true;
                textBox25.Visible = false;
                textBox24.Visible = true;
                textBox23.Visible = true;
                textBox22.Visible = true;
                textBox21.Visible = false;
                textBox20.Visible = false;
                textBox19.Visible = false;
                textBox18.Visible = false;
                textBox17.Visible = false;
            }
            else if (numericUpDown3.Value == 4 && numericUpDown4.Value == 4)
            {
                textBox32.Visible = true;
                textBox31.Visible = true;
                textBox30.Visible = true;
                textBox29.Visible = true;
                textBox28.Visible = true;
                textBox27.Visible = true;
                textBox26.Visible = true;
                textBox25.Visible = true;
                textBox24.Visible = true;
                textBox23.Visible = true;
                textBox22.Visible = true;
                textBox21.Visible = true;
                textBox20.Visible = true;
                textBox19.Visible = true;
                textBox18.Visible = true;
                textBox17.Visible = true;
            }
            if (numericUpDown1.Value == numericUpDown3.Value && numericUpDown2.Value == numericUpDown4.Value)
            {
                button4.Visible = true;
                button5.Visible = true;
            }
            else
            {
                button4.Visible = false;
                button5.Visible = false;
            }
            label23.Visible = true;
            label24.Visible = true;
            if (numericUpDown2.Value==numericUpDown3.Value)
            {
                button6.Visible = true;
            }
            else
            {
                button6.Visible = false;
            }
            if (numericUpDown1.Value == numericUpDown4.Value)
            {
                button7.Visible = true;
            }
            else
            {
                button7.Visible = false;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (numericUpDown1.Value == 2 && numericUpDown2.Value == 2)
                {
                    if (!(textBox1.Text == "" || textBox2.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox32.Text == "" || textBox31.Text == "" || textBox28.Text == "" || textBox27.Text == ""))
                    {
                        label6.Visible = true;
                        label7.Visible = true;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = true;
                        label11.Visible = true;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        float c1 = float.Parse(textBox1.Text) + float.Parse(textBox32.Text), c2 = float.Parse(textBox2.Text) + float.Parse(textBox31.Text), c3 = float.Parse(textBox5.Text) + float.Parse(textBox28.Text), c4 = float.Parse(textBox6.Text) + float.Parse(textBox27.Text);
                        label6.Text = c1.ToString();
                        label7.Text = c2.ToString();
                        label10.Text = c3.ToString();
                        label11.Text = c4.ToString();
                        label22.Visible = false;
                    }

                    else
                    {
                        label6.Visible = false;
                        label7.Visible = false;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = false;
                        label11.Visible = false;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        label22.Visible = true;
                    }
                }
                if (numericUpDown1.Value == 2 && numericUpDown2.Value == 3)
                {
                    if (!(textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox7.Text == "" || textBox32.Text == "" || textBox31.Text == "" || textBox30.Text == "" || textBox28.Text == "" || textBox27.Text == "" || textBox26.Text == ""))
                    {
                        label6.Visible = true;
                        label7.Visible = true;
                        label8.Visible = true;
                        label9.Visible = false;
                        label10.Visible = true;
                        label11.Visible = true;
                        label12.Visible = true;
                        label13.Visible = false;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        float c1 = float.Parse(textBox1.Text) + float.Parse(textBox32.Text), c2 = float.Parse(textBox2.Text) + float.Parse(textBox31.Text), c3 = float.Parse(textBox3.Text) + float.Parse(textBox30.Text), c4 = float.Parse(textBox5.Text) + float.Parse(textBox28.Text), c5 = float.Parse(textBox6.Text) + float.Parse(textBox27.Text), c6 = float.Parse(textBox7.Text) + float.Parse(textBox26.Text);
                        label6.Text = c1.ToString();
                        label7.Text = c2.ToString();
                        label8.Text = c3.ToString();
                        label10.Text = c4.ToString();
                        label11.Text = c5.ToString();
                        label12.Text = c6.ToString();
                        label22.Visible = false;
                    }

                    else
                    {
                        label6.Visible = false;
                        label7.Visible = false;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = false;
                        label11.Visible = false;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        label22.Visible = true;
                    }
                }
                if (numericUpDown1.Value == 2 && numericUpDown2.Value == 4)
                {
                    if (!(textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox7.Text == "" || textBox8.Text == "" || textBox32.Text == "" || textBox31.Text == "" || textBox30.Text == "" || textBox29.Text == "" || textBox28.Text == "" || textBox27.Text == "" || textBox26.Text == "" || textBox25.Text == ""))
                    {
                        label6.Visible = true;
                        label7.Visible = true;
                        label8.Visible = true;
                        label9.Visible = true;
                        label10.Visible = true;
                        label11.Visible = true;
                        label12.Visible = true;
                        label13.Visible = true;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        float c1 = float.Parse(textBox1.Text) + float.Parse(textBox32.Text), c2 = float.Parse(textBox2.Text) + float.Parse(textBox31.Text), c3 = float.Parse(textBox3.Text) + float.Parse(textBox30.Text), c4 = float.Parse(textBox4.Text) + float.Parse(textBox29.Text), c5 = float.Parse(textBox5.Text) + float.Parse(textBox28.Text), c6 = float.Parse(textBox6.Text) + float.Parse(textBox27.Text), c7 = float.Parse(textBox7.Text) + float.Parse(textBox26.Text), c8 = float.Parse(textBox8.Text) + float.Parse(textBox25.Text);
                        label6.Text = c1.ToString();
                        label7.Text = c2.ToString();
                        label8.Text = c3.ToString();
                        label9.Text = c4.ToString();
                        label10.Text = c5.ToString();
                        label11.Text = c6.ToString();
                        label12.Text = c7.ToString();
                        label13.Text = c8.ToString();
                        label22.Visible = false;
                    }

                    else
                    {
                        label6.Visible = false;
                        label7.Visible = false;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = false;
                        label11.Visible = false;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        label22.Visible = true;
                    }
                }
                if (numericUpDown1.Value == 4 && numericUpDown2.Value == 2)
                {
                    if (!(textBox1.Text == "" || textBox2.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox9.Text == "" || textBox10.Text == "" || textBox13.Text == "" || textBox14.Text == "" || textBox32.Text == "" || textBox31.Text == "" || textBox28.Text == "" || textBox27.Text == "" || textBox24.Text == "" || textBox23.Text == "" || textBox20.Text == "" || textBox19.Text == ""))
                    {
                        label6.Visible = true;
                        label7.Visible = true;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = true;
                        label11.Visible = true;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = true;
                        label15.Visible = true;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = true;
                        label19.Visible = true;
                        label20.Visible = false;
                        label21.Visible = false;
                        float c1 = float.Parse(textBox1.Text) + float.Parse(textBox32.Text), c2 = float.Parse(textBox2.Text) + float.Parse(textBox31.Text), c3 = float.Parse(textBox5.Text) + float.Parse(textBox28.Text), c4 = float.Parse(textBox6.Text) + float.Parse(textBox27.Text), c5 = float.Parse(textBox9.Text) + float.Parse(textBox24.Text), c6 = float.Parse(textBox10.Text) + float.Parse(textBox23.Text), c7 = float.Parse(textBox13.Text) + float.Parse(textBox20.Text), c8 = float.Parse(textBox14.Text) + float.Parse(textBox19.Text);
                        label6.Text = c1.ToString();
                        label7.Text = c2.ToString();
                        label10.Text = c3.ToString();
                        label11.Text = c4.ToString();
                        label14.Text = c5.ToString();
                        label15.Text = c6.ToString();
                        label18.Text = c7.ToString();
                        label19.Text = c8.ToString();
                        label22.Visible = false;
                    }

                    else
                    {
                        label6.Visible = false;
                        label7.Visible = false;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = false;
                        label11.Visible = false;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        label22.Visible = true;
                    }
                }
                if (numericUpDown1.Value == 4 && numericUpDown2.Value == 3)
                {
                    if (!(textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox7.Text == "" || textBox9.Text == "" || textBox10.Text == "" || textBox11.Text == "" || textBox13.Text == "" || textBox14.Text == "" || textBox15.Text == "" || textBox32.Text == "" || textBox31.Text == "" || textBox30.Text == "" || textBox28.Text == "" || textBox27.Text == "" || textBox26.Text == "" || textBox24.Text == "" || textBox23.Text == "" || textBox22.Text == "" || textBox20.Text == "" || textBox19.Text == "" || textBox18.Text == ""))
                    {
                        label6.Visible = true;
                        label7.Visible = true;
                        label8.Visible = true;
                        label9.Visible = false;
                        label10.Visible = true;
                        label11.Visible = true;
                        label12.Visible = true;
                        label13.Visible = false;
                        label14.Visible = true;
                        label15.Visible = true;
                        label16.Visible = true;
                        label17.Visible = false;
                        label18.Visible = true;
                        label19.Visible = true;
                        label20.Visible = true;
                        label21.Visible = false;
                        float c1 = float.Parse(textBox1.Text) + float.Parse(textBox32.Text), c2 = float.Parse(textBox2.Text) + float.Parse(textBox31.Text), c3 = float.Parse(textBox3.Text) + float.Parse(textBox30.Text), c4 = float.Parse(textBox5.Text) + float.Parse(textBox28.Text), c5 = float.Parse(textBox6.Text) + float.Parse(textBox27.Text), c6 = float.Parse(textBox7.Text) + float.Parse(textBox26.Text), c7 = float.Parse(textBox9.Text) + float.Parse(textBox24.Text), c8 = float.Parse(textBox10.Text) + float.Parse(textBox23.Text), c9 = float.Parse(textBox11.Text) + float.Parse(textBox22.Text), c10 = float.Parse(textBox13.Text) + float.Parse(textBox20.Text), c11 = float.Parse(textBox14.Text) + float.Parse(textBox19.Text), c12 = float.Parse(textBox15.Text) + float.Parse(textBox18.Text);
                        label6.Text = c1.ToString();
                        label7.Text = c2.ToString();
                        label8.Text = c3.ToString();
                        label10.Text = c4.ToString();
                        label11.Text = c5.ToString();
                        label12.Text = c6.ToString();
                        label14.Text = c7.ToString();
                        label15.Text = c8.ToString();
                        label16.Text = c9.ToString();
                        label18.Text = c10.ToString();
                        label19.Text = c11.ToString();
                        label20.Text = c12.ToString();
                        label22.Visible = false;
                    }

                    else
                    {
                        label6.Visible = false;
                        label7.Visible = false;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = false;
                        label11.Visible = false;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        label22.Visible = true;
                    }
                }
                if (numericUpDown1.Value == 3 && numericUpDown2.Value == 4)
                {
                    if (!(textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox7.Text == "" || textBox8.Text == "" || textBox9.Text == "" || textBox10.Text == "" || textBox11.Text == "" || textBox12.Text == "" || textBox32.Text == "" || textBox31.Text == "" || textBox30.Text == "" || textBox29.Text == "" || textBox28.Text == "" || textBox27.Text == "" || textBox26.Text == "" || textBox25.Text == "" || textBox24.Text == "" || textBox23.Text == "" || textBox22.Text == "" || textBox21.Text == ""))
                    {
                        label6.Visible = true;
                        label7.Visible = true;
                        label8.Visible = true;
                        label9.Visible = true;
                        label10.Visible = true;
                        label11.Visible = true;
                        label12.Visible = true;
                        label13.Visible = true;
                        label14.Visible = true;
                        label15.Visible = true;
                        label16.Visible = true;
                        label17.Visible = true;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        float c1 = float.Parse(textBox1.Text) + float.Parse(textBox32.Text), c2 = float.Parse(textBox2.Text) + float.Parse(textBox31.Text), c3 = float.Parse(textBox3.Text) + float.Parse(textBox30.Text), c4 = float.Parse(textBox4.Text) + float.Parse(textBox29.Text), c5 = float.Parse(textBox5.Text) + float.Parse(textBox28.Text), c6 = float.Parse(textBox6.Text) + float.Parse(textBox27.Text), c7 = float.Parse(textBox7.Text) + float.Parse(textBox26.Text), c8 = float.Parse(textBox8.Text) + float.Parse(textBox25.Text), c9 = float.Parse(textBox9.Text) + float.Parse(textBox24.Text), c10 = float.Parse(textBox10.Text) + float.Parse(textBox23.Text), c11 = float.Parse(textBox11.Text) + float.Parse(textBox22.Text), c12 = float.Parse(textBox12.Text) + float.Parse(textBox21.Text);
                        label6.Text = c1.ToString();
                        label7.Text = c2.ToString();
                        label8.Text = c3.ToString();
                        label9.Text = c4.ToString();
                        label10.Text = c5.ToString();
                        label11.Text = c6.ToString();
                        label12.Text = c7.ToString();
                        label13.Text = c8.ToString();
                        label14.Text = c9.ToString();
                        label15.Text = c10.ToString();
                        label16.Text = c11.ToString();
                        label17.Text = c12.ToString();
                        label22.Visible = false;
                    }

                    else
                    {
                        label6.Visible = false;
                        label7.Visible = false;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = false;
                        label11.Visible = false;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        label22.Visible = true;
                    }
                }
                if (numericUpDown1.Value == 4 && numericUpDown2.Value == 4)
                {
                    if (!(textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox7.Text == "" || textBox8.Text == "" || textBox9.Text == "" || textBox10.Text == "" || textBox11.Text == "" || textBox12.Text == "" || textBox13.Text == "" || textBox14.Text == "" || textBox15.Text == "" || textBox16.Text == "" || textBox32.Text == "" || textBox31.Text == "" || textBox30.Text == "" || textBox29.Text == "" || textBox28.Text == "" || textBox27.Text == "" || textBox26.Text == "" || textBox25.Text == "" || textBox24.Text == "" || textBox23.Text == "" || textBox22.Text == "" || textBox21.Text == "" || textBox20.Text == "" || textBox19.Text == "" || textBox18.Text == "" || textBox17.Text == ""))
                    {
                        label6.Visible = true;
                        label7.Visible = true;
                        label8.Visible = true;
                        label9.Visible = true;
                        label10.Visible = true;
                        label11.Visible = true;
                        label12.Visible = true;
                        label13.Visible = true;
                        label14.Visible = true;
                        label15.Visible = true;
                        label16.Visible = true;
                        label17.Visible = true;
                        label18.Visible = true;
                        label19.Visible = true;
                        label20.Visible = true;
                        label21.Visible = true;
                        float c1 = float.Parse(textBox1.Text) + float.Parse(textBox32.Text), c2 = float.Parse(textBox2.Text) + float.Parse(textBox31.Text), c3 = float.Parse(textBox3.Text) + float.Parse(textBox30.Text), c4 = float.Parse(textBox4.Text) + float.Parse(textBox29.Text), c5 = float.Parse(textBox5.Text) + float.Parse(textBox28.Text), c6 = float.Parse(textBox6.Text) + float.Parse(textBox27.Text), c7 = float.Parse(textBox7.Text) + float.Parse(textBox26.Text), c8 = float.Parse(textBox8.Text) + float.Parse(textBox25.Text), c9 = float.Parse(textBox9.Text) + float.Parse(textBox24.Text), c10 = float.Parse(textBox10.Text) + float.Parse(textBox23.Text), c11 = float.Parse(textBox11.Text) + float.Parse(textBox22.Text), c12 = float.Parse(textBox12.Text) + float.Parse(textBox21.Text), c13 = float.Parse(textBox13.Text) + float.Parse(textBox20.Text), c14 = float.Parse(textBox14.Text) + float.Parse(textBox19.Text), c15 = float.Parse(textBox15.Text) + float.Parse(textBox18.Text), c16 = float.Parse(textBox16.Text) + float.Parse(textBox17.Text);
                        label6.Text = c1.ToString();
                        label7.Text = c2.ToString();
                        label8.Text = c3.ToString();
                        label9.Text = c4.ToString();
                        label10.Text = c5.ToString();
                        label11.Text = c6.ToString();
                        label12.Text = c7.ToString();
                        label13.Text = c8.ToString();
                        label14.Text = c9.ToString();
                        label15.Text = c10.ToString();
                        label16.Text = c11.ToString();
                        label17.Text = c12.ToString();
                        label18.Text = c13.ToString();
                        label19.Text = c14.ToString();
                        label20.Text = c15.ToString();
                        label21.Text = c16.ToString();
                        label22.Visible = false;
                    }

                    else
                    {
                        label6.Visible = false;
                        label7.Visible = false;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = false;
                        label11.Visible = false;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        label22.Visible = true;
                    }
                }
                if (numericUpDown1.Value == 3 && numericUpDown2.Value == 3)
                {
                    if (!(textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox7.Text == "" || textBox9.Text == "" || textBox10.Text == "" || textBox11.Text == "" || textBox32.Text == "" || textBox31.Text == "" || textBox30.Text == "" || textBox28.Text == "" || textBox27.Text == "" || textBox26.Text == "" || textBox24.Text == "" || textBox23.Text == "" || textBox22.Text == ""))
                    {
                        label6.Visible = true;
                        label7.Visible = true;
                        label8.Visible = true;
                        label9.Visible = false;
                        label10.Visible = true;
                        label11.Visible = true;
                        label12.Visible = true;
                        label13.Visible = false;
                        label14.Visible = true;
                        label15.Visible = true;
                        label16.Visible = true;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        float c1 = float.Parse(textBox1.Text) + float.Parse(textBox32.Text), c2 = float.Parse(textBox2.Text) + float.Parse(textBox31.Text), c3 = float.Parse(textBox3.Text) + float.Parse(textBox30.Text), c5 = float.Parse(textBox5.Text) + float.Parse(textBox28.Text), c6 = float.Parse(textBox6.Text) + float.Parse(textBox27.Text), c7 = float.Parse(textBox7.Text) + float.Parse(textBox26.Text), c9 = float.Parse(textBox9.Text) + float.Parse(textBox24.Text), c10 = float.Parse(textBox10.Text) + float.Parse(textBox23.Text), c11 = float.Parse(textBox11.Text) + float.Parse(textBox22.Text);
                        label6.Text = c1.ToString();
                        label7.Text = c2.ToString();
                        label8.Text = c3.ToString();
                        label10.Text = c5.ToString();
                        label11.Text = c6.ToString();
                        label12.Text = c7.ToString();
                        label14.Text = c9.ToString();
                        label15.Text = c10.ToString();
                        label16.Text = c11.ToString();
                        label22.Visible = false;
                    }

                    else
                    {
                        label6.Visible = false;
                        label7.Visible = false;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = false;
                        label11.Visible = false;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        label22.Visible = true;
                    }
                }
                if (numericUpDown1.Value == 3 && numericUpDown2.Value == 2)
                {
                    if (!(textBox1.Text == "" || textBox2.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox9.Text == "" || textBox10.Text == "" || textBox32.Text == "" || textBox31.Text == "" || textBox28.Text == "" || textBox27.Text == "" || textBox24.Text == "" || textBox23.Text == ""))
                    {
                        label6.Visible = true;
                        label7.Visible = true;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = true;
                        label11.Visible = true;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = true;
                        label15.Visible = true;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        float c1 = float.Parse(textBox1.Text) + float.Parse(textBox32.Text), c2 = float.Parse(textBox2.Text) + float.Parse(textBox31.Text), c5 = float.Parse(textBox5.Text) + float.Parse(textBox28.Text), c6 = float.Parse(textBox6.Text) + float.Parse(textBox27.Text), c9 = float.Parse(textBox9.Text) + float.Parse(textBox24.Text), c10 = float.Parse(textBox10.Text) + float.Parse(textBox23.Text);
                        label6.Text = c1.ToString();
                        label7.Text = c2.ToString();
                        label10.Text = c5.ToString();
                        label11.Text = c6.ToString();
                        label14.Text = c9.ToString();
                        label15.Text = c10.ToString();
                        label22.Visible = false;
                    }

                    else
                    {
                        label6.Visible = false;
                        label7.Visible = false;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = false;
                        label11.Visible = false;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        label22.Visible = true;
                    }
                }
            }
            catch
            {

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                if (numericUpDown1.Value == 2 && numericUpDown2.Value == 2)
                {
                    if (!(textBox1.Text == "" || textBox2.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox32.Text == "" || textBox31.Text == "" || textBox28.Text == "" || textBox27.Text == ""))
                    {
                        label6.Visible = true;
                        label7.Visible = true;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = true;
                        label11.Visible = true;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        float c1 = float.Parse(textBox1.Text) - float.Parse(textBox32.Text), c2 = float.Parse(textBox2.Text) - float.Parse(textBox31.Text), c3 = float.Parse(textBox5.Text) - float.Parse(textBox28.Text), c4 = float.Parse(textBox6.Text) - float.Parse(textBox27.Text);
                        label6.Text = c1.ToString();
                        label7.Text = c2.ToString();
                        label10.Text = c3.ToString();
                        label11.Text = c4.ToString();
                        label22.Visible = false;
                    }

                    else
                    {
                        label6.Visible = false;
                        label7.Visible = false;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = false;
                        label11.Visible = false;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        label22.Visible = true;
                    }
                }
                if (numericUpDown1.Value == 2 && numericUpDown2.Value == 3)
                {
                    if (!(textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox7.Text == "" || textBox32.Text == "" || textBox31.Text == "" || textBox30.Text == "" || textBox28.Text == "" || textBox27.Text == "" || textBox26.Text == ""))
                    {
                        label6.Visible = true;
                        label7.Visible = true;
                        label8.Visible = true;
                        label9.Visible = false;
                        label10.Visible = true;
                        label11.Visible = true;
                        label12.Visible = true;
                        label13.Visible = false;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        float c1 = float.Parse(textBox1.Text) - float.Parse(textBox32.Text), c2 = float.Parse(textBox2.Text) - float.Parse(textBox31.Text), c3 = float.Parse(textBox3.Text) - float.Parse(textBox30.Text), c4 = float.Parse(textBox5.Text) - float.Parse(textBox28.Text), c5 = float.Parse(textBox6.Text) - float.Parse(textBox27.Text), c6 = float.Parse(textBox7.Text) - float.Parse(textBox26.Text);
                        label6.Text = c1.ToString();
                        label7.Text = c2.ToString();
                        label8.Text = c3.ToString();
                        label10.Text = c4.ToString();
                        label11.Text = c5.ToString();
                        label12.Text = c6.ToString();
                        label22.Visible = false;
                    }

                    else
                    {
                        label6.Visible = false;
                        label7.Visible = false;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = false;
                        label11.Visible = false;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        label22.Visible = true;
                    }
                }
                if (numericUpDown1.Value == 2 && numericUpDown2.Value == 4)
                {
                    if (!(textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox7.Text == "" || textBox8.Text == "" || textBox32.Text == "" || textBox31.Text == "" || textBox30.Text == "" || textBox29.Text == "" || textBox28.Text == "" || textBox27.Text == "" || textBox26.Text == "" || textBox25.Text == ""))
                    {
                        label6.Visible = true;
                        label7.Visible = true;
                        label8.Visible = true;
                        label9.Visible = true;
                        label10.Visible = true;
                        label11.Visible = true;
                        label12.Visible = true;
                        label13.Visible = true;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        float c1 = float.Parse(textBox1.Text) - float.Parse(textBox32.Text), c2 = float.Parse(textBox2.Text) - float.Parse(textBox31.Text), c3 = float.Parse(textBox3.Text) - float.Parse(textBox30.Text), c4 = float.Parse(textBox4.Text) - float.Parse(textBox29.Text), c5 = float.Parse(textBox5.Text) - float.Parse(textBox28.Text), c6 = float.Parse(textBox6.Text) - float.Parse(textBox27.Text), c7 = float.Parse(textBox7.Text) - float.Parse(textBox26.Text), c8 = float.Parse(textBox8.Text) - float.Parse(textBox25.Text);
                        label6.Text = c1.ToString();
                        label7.Text = c2.ToString();
                        label8.Text = c3.ToString();
                        label9.Text = c4.ToString();
                        label10.Text = c5.ToString();
                        label11.Text = c6.ToString();
                        label12.Text = c7.ToString();
                        label13.Text = c8.ToString();
                        label22.Visible = false;
                    }

                    else
                    {
                        label6.Visible = false;
                        label7.Visible = false;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = false;
                        label11.Visible = false;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        label22.Visible = true;
                    }
                }
                if (numericUpDown1.Value == 4 && numericUpDown2.Value == 2)
                {
                    if (!(textBox1.Text == "" || textBox2.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox9.Text == "" || textBox10.Text == "" || textBox13.Text == "" || textBox14.Text == "" || textBox32.Text == "" || textBox31.Text == "" || textBox28.Text == "" || textBox27.Text == "" || textBox24.Text == "" || textBox23.Text == "" || textBox20.Text == "" || textBox19.Text == ""))
                    {
                        label6.Visible = true;
                        label7.Visible = true;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = true;
                        label11.Visible = true;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = true;
                        label15.Visible = true;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = true;
                        label19.Visible = true;
                        label20.Visible = false;
                        label21.Visible = false;
                        float c1 = float.Parse(textBox1.Text) - float.Parse(textBox32.Text), c2 = float.Parse(textBox2.Text) - float.Parse(textBox31.Text), c3 = float.Parse(textBox5.Text) - float.Parse(textBox28.Text), c4 = float.Parse(textBox6.Text) - float.Parse(textBox27.Text), c5 = float.Parse(textBox9.Text) - float.Parse(textBox24.Text), c6 = float.Parse(textBox10.Text) - float.Parse(textBox23.Text), c7 = float.Parse(textBox13.Text) - float.Parse(textBox20.Text), c8 = float.Parse(textBox14.Text) - float.Parse(textBox19.Text);
                        label6.Text = c1.ToString();
                        label7.Text = c2.ToString();
                        label10.Text = c3.ToString();
                        label11.Text = c4.ToString();
                        label14.Text = c5.ToString();
                        label15.Text = c6.ToString();
                        label18.Text = c7.ToString();
                        label19.Text = c8.ToString();
                        label22.Visible = false;
                    }

                    else
                    {
                        label6.Visible = false;
                        label7.Visible = false;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = false;
                        label11.Visible = false;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        label22.Visible = true;
                    }
                }
                if (numericUpDown1.Value == 4 && numericUpDown2.Value == 3)
                {
                    if (!(textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox7.Text == "" || textBox9.Text == "" || textBox10.Text == "" || textBox11.Text == "" || textBox13.Text == "" || textBox14.Text == "" || textBox15.Text == "" || textBox32.Text == "" || textBox31.Text == "" || textBox30.Text == "" || textBox28.Text == "" || textBox27.Text == "" || textBox26.Text == "" || textBox24.Text == "" || textBox23.Text == "" || textBox22.Text == "" || textBox20.Text == "" || textBox19.Text == "" || textBox18.Text == ""))
                    {
                        label6.Visible = true;
                        label7.Visible = true;
                        label8.Visible = true;
                        label9.Visible = false;
                        label10.Visible = true;
                        label11.Visible = true;
                        label12.Visible = true;
                        label13.Visible = false;
                        label14.Visible = true;
                        label15.Visible = true;
                        label16.Visible = true;
                        label17.Visible = false;
                        label18.Visible = true;
                        label19.Visible = true;
                        label20.Visible = true;
                        label21.Visible = false;
                        float c1 = float.Parse(textBox1.Text) - float.Parse(textBox32.Text), c2 = float.Parse(textBox2.Text) - float.Parse(textBox31.Text), c3 = float.Parse(textBox3.Text) - float.Parse(textBox30.Text), c4 = float.Parse(textBox5.Text) - float.Parse(textBox28.Text), c5 = float.Parse(textBox6.Text) - float.Parse(textBox27.Text), c6 = float.Parse(textBox7.Text) - float.Parse(textBox26.Text), c7 = float.Parse(textBox9.Text) - float.Parse(textBox24.Text), c8 = float.Parse(textBox10.Text) - float.Parse(textBox23.Text), c9 = float.Parse(textBox11.Text) - float.Parse(textBox22.Text), c10 = float.Parse(textBox13.Text) - float.Parse(textBox20.Text), c11 = float.Parse(textBox14.Text) - float.Parse(textBox19.Text), c12 = float.Parse(textBox15.Text) - float.Parse(textBox18.Text);
                        label6.Text = c1.ToString();
                        label7.Text = c2.ToString();
                        label8.Text = c3.ToString();
                        label10.Text = c4.ToString();
                        label11.Text = c5.ToString();
                        label12.Text = c6.ToString();
                        label14.Text = c7.ToString();
                        label15.Text = c8.ToString();
                        label16.Text = c9.ToString();
                        label18.Text = c10.ToString();
                        label19.Text = c11.ToString();
                        label20.Text = c12.ToString();
                        label22.Visible = false;
                    }

                    else
                    {
                        label6.Visible = false;
                        label7.Visible = false;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = false;
                        label11.Visible = false;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        label22.Visible = true;
                    }
                }
                if (numericUpDown1.Value == 3 && numericUpDown2.Value == 4)
                {
                    if (!(textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox7.Text == "" || textBox8.Text == "" || textBox9.Text == "" || textBox10.Text == "" || textBox11.Text == "" || textBox12.Text == "" || textBox32.Text == "" || textBox31.Text == "" || textBox30.Text == "" || textBox29.Text == "" || textBox28.Text == "" || textBox27.Text == "" || textBox26.Text == "" || textBox25.Text == "" || textBox24.Text == "" || textBox23.Text == "" || textBox22.Text == "" || textBox21.Text == ""))
                    {
                        label6.Visible = true;
                        label7.Visible = true;
                        label8.Visible = true;
                        label9.Visible = true;
                        label10.Visible = true;
                        label11.Visible = true;
                        label12.Visible = true;
                        label13.Visible = true;
                        label14.Visible = true;
                        label15.Visible = true;
                        label16.Visible = true;
                        label17.Visible = true;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        float c1 = float.Parse(textBox1.Text) - float.Parse(textBox32.Text), c2 = float.Parse(textBox2.Text) - float.Parse(textBox31.Text), c3 = float.Parse(textBox3.Text) - float.Parse(textBox30.Text), c4 = float.Parse(textBox4.Text) - float.Parse(textBox29.Text), c5 = float.Parse(textBox5.Text) - float.Parse(textBox28.Text), c6 = float.Parse(textBox6.Text) - float.Parse(textBox27.Text), c7 = float.Parse(textBox7.Text) - float.Parse(textBox26.Text), c8 = float.Parse(textBox8.Text) - float.Parse(textBox25.Text), c9 = float.Parse(textBox9.Text) - float.Parse(textBox24.Text), c10 = float.Parse(textBox10.Text) - float.Parse(textBox23.Text), c11 = float.Parse(textBox11.Text) - float.Parse(textBox22.Text), c12 = float.Parse(textBox12.Text) - float.Parse(textBox21.Text);
                        label6.Text = c1.ToString();
                        label7.Text = c2.ToString();
                        label8.Text = c3.ToString();
                        label9.Text = c4.ToString();
                        label10.Text = c5.ToString();
                        label11.Text = c6.ToString();
                        label12.Text = c7.ToString();
                        label13.Text = c8.ToString();
                        label14.Text = c9.ToString();
                        label15.Text = c10.ToString();
                        label16.Text = c11.ToString();
                        label17.Text = c12.ToString();
                        label22.Visible = false;
                    }

                    else
                    {
                        label6.Visible = false;
                        label7.Visible = false;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = false;
                        label11.Visible = false;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        label22.Visible = true;
                    }
                }
                if (numericUpDown1.Value == 4 && numericUpDown2.Value == 4)
                {
                    if (!(textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox7.Text == "" || textBox8.Text == "" || textBox9.Text == "" || textBox10.Text == "" || textBox11.Text == "" || textBox12.Text == "" || textBox13.Text == "" || textBox14.Text == "" || textBox15.Text == "" || textBox16.Text == "" || textBox32.Text == "" || textBox31.Text == "" || textBox30.Text == "" || textBox29.Text == "" || textBox28.Text == "" || textBox27.Text == "" || textBox26.Text == "" || textBox25.Text == "" || textBox24.Text == "" || textBox23.Text == "" || textBox22.Text == "" || textBox21.Text == "" || textBox20.Text == "" || textBox19.Text == "" || textBox18.Text == "" || textBox17.Text == ""))
                    {
                        label6.Visible = true;
                        label7.Visible = true;
                        label8.Visible = true;
                        label9.Visible = true;
                        label10.Visible = true;
                        label11.Visible = true;
                        label12.Visible = true;
                        label13.Visible = true;
                        label14.Visible = true;
                        label15.Visible = true;
                        label16.Visible = true;
                        label17.Visible = true;
                        label18.Visible = true;
                        label19.Visible = true;
                        label20.Visible = true;
                        label21.Visible = true;
                        float c1 = float.Parse(textBox1.Text) - float.Parse(textBox32.Text), c2 = float.Parse(textBox2.Text) - float.Parse(textBox31.Text), c3 = float.Parse(textBox3.Text) - float.Parse(textBox30.Text), c4 = float.Parse(textBox4.Text) - float.Parse(textBox29.Text), c5 = float.Parse(textBox5.Text) - float.Parse(textBox28.Text), c6 = float.Parse(textBox6.Text) - float.Parse(textBox27.Text), c7 = float.Parse(textBox7.Text) - float.Parse(textBox26.Text), c8 = float.Parse(textBox8.Text) - float.Parse(textBox25.Text), c9 = float.Parse(textBox9.Text) - float.Parse(textBox24.Text), c10 = float.Parse(textBox10.Text) - float.Parse(textBox23.Text), c11 = float.Parse(textBox11.Text) - float.Parse(textBox22.Text), c12 = float.Parse(textBox12.Text) - float.Parse(textBox21.Text), c13 = float.Parse(textBox13.Text) - float.Parse(textBox20.Text), c14 = float.Parse(textBox14.Text) - float.Parse(textBox19.Text), c15 = float.Parse(textBox15.Text) - float.Parse(textBox18.Text), c16 = float.Parse(textBox16.Text) - float.Parse(textBox17.Text);
                        label6.Text = c1.ToString();
                        label7.Text = c2.ToString();
                        label8.Text = c3.ToString();
                        label9.Text = c4.ToString();
                        label10.Text = c5.ToString();
                        label11.Text = c6.ToString();
                        label12.Text = c7.ToString();
                        label13.Text = c8.ToString();
                        label14.Text = c9.ToString();
                        label15.Text = c10.ToString();
                        label16.Text = c11.ToString();
                        label17.Text = c12.ToString();
                        label18.Text = c13.ToString();
                        label19.Text = c14.ToString();
                        label20.Text = c15.ToString();
                        label21.Text = c16.ToString();
                        label22.Visible = false;
                    }

                    else
                    {
                        label6.Visible = false;
                        label7.Visible = false;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = false;
                        label11.Visible = false;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        label22.Visible = true;
                    }
                }
                if (numericUpDown1.Value == 3 && numericUpDown2.Value == 3)
                {
                    if (!(textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox7.Text == "" || textBox9.Text == "" || textBox10.Text == "" || textBox11.Text == "" || textBox32.Text == "" || textBox31.Text == "" || textBox30.Text == "" || textBox28.Text == "" || textBox27.Text == "" || textBox26.Text == "" || textBox24.Text == "" || textBox23.Text == "" || textBox22.Text == ""))
                    {
                        label6.Visible = true;
                        label7.Visible = true;
                        label8.Visible = true;
                        label9.Visible = false;
                        label10.Visible = true;
                        label11.Visible = true;
                        label12.Visible = true;
                        label13.Visible = false;
                        label14.Visible = true;
                        label15.Visible = true;
                        label16.Visible = true;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        float c1 = float.Parse(textBox1.Text) - float.Parse(textBox32.Text), c2 = float.Parse(textBox2.Text) - float.Parse(textBox31.Text), c3 = float.Parse(textBox3.Text) - float.Parse(textBox30.Text), c5 = float.Parse(textBox5.Text) - float.Parse(textBox28.Text), c6 = float.Parse(textBox6.Text) - float.Parse(textBox27.Text), c7 = float.Parse(textBox7.Text) - float.Parse(textBox26.Text), c9 = float.Parse(textBox9.Text) - float.Parse(textBox24.Text), c10 = float.Parse(textBox10.Text) - float.Parse(textBox23.Text), c11 = float.Parse(textBox11.Text) - float.Parse(textBox22.Text);
                        label6.Text = c1.ToString();
                        label7.Text = c2.ToString();
                        label8.Text = c3.ToString();
                        label10.Text = c5.ToString();
                        label11.Text = c6.ToString();
                        label12.Text = c7.ToString();
                        label14.Text = c9.ToString();
                        label15.Text = c10.ToString();
                        label16.Text = c11.ToString();
                        label22.Visible = false;
                    }

                    else
                    {
                        label6.Visible = false;
                        label7.Visible = false;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = false;
                        label11.Visible = false;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        label22.Visible = true;
                    }
                }
                if (numericUpDown1.Value == 3 && numericUpDown2.Value == 2)
                {
                    if (!(textBox1.Text == "" || textBox2.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox9.Text == "" || textBox10.Text == "" || textBox32.Text == "" || textBox31.Text == "" || textBox28.Text == "" || textBox27.Text == "" || textBox24.Text == "" || textBox23.Text == ""))
                    {
                        label6.Visible = true;
                        label7.Visible = true;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = true;
                        label11.Visible = true;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = true;
                        label15.Visible = true;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        float c1 = float.Parse(textBox1.Text) - float.Parse(textBox32.Text), c2 = float.Parse(textBox2.Text) - float.Parse(textBox31.Text), c5 = float.Parse(textBox5.Text) - float.Parse(textBox28.Text), c6 = float.Parse(textBox6.Text) - float.Parse(textBox27.Text), c9 = float.Parse(textBox9.Text) - float.Parse(textBox24.Text), c10 = float.Parse(textBox10.Text) - float.Parse(textBox23.Text);
                        label6.Text = c1.ToString();
                        label7.Text = c2.ToString();
                        label10.Text = c5.ToString();
                        label11.Text = c6.ToString();
                        label14.Text = c9.ToString();
                        label15.Text = c10.ToString();
                        label22.Visible = false;
                    }

                    else
                    {
                        label6.Visible = false;
                        label7.Visible = false;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = false;
                        label11.Visible = false;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        label22.Visible = true;
                    }
                }
            }
            catch
            {

            }
        }
        bool provjera()
        {
            try
            {
                int nu1 = int.Parse(numericUpDown1.Value.ToString()), nu2 = int.Parse(numericUpDown2.Value.ToString()), nu3 = int.Parse(numericUpDown3.Value.ToString()), nu4 = int.Parse(numericUpDown4.Value.ToString());
                bool mat1 = true, mat2 = true;
                for (int i = 0; i < nu1; i++)
                {
                    for (int j = 0; j < nu2; j++)
                    {
                        if (i == 0 && j == 0)
                        {
                            if (textBox1.Text == "")
                            {
                                mat2 = false;
                            }
                        }
                        if (i == 0 && j == 1)
                        {
                            if (textBox2.Text == "")
                            {
                                mat2 = false;
                            }
                        }
                        if (i == 0 && j == 2)
                        {
                            if (textBox3.Text == "")
                            {
                                mat2 = false;
                            }
                        }
                        if (i == 0 && j == 3)
                        {
                            if (textBox4.Text == "")
                            {
                                mat2 = false;
                            }
                        }
                        if (i == 1 && j == 0)
                        {
                            if (textBox5.Text == "")
                            {
                                mat2 = false;
                            }
                        }
                        if (i == 1 && j == 1)
                        {
                            if (textBox6.Text == "")
                            {
                                mat2 = false;
                            }
                        }
                        if (i == 1 && j == 2)
                        {
                            if (textBox7.Text == "")
                            {
                                mat2 = false;
                            }
                        }
                        if (i == 1 && j == 3)
                        {
                            if (textBox8.Text == "")
                            {
                                mat2 = false;
                            }
                        }
                        if (i == 2 && j == 0)
                        {
                            if (textBox9.Text == "")
                            {
                                mat2 = false;
                            }
                        }
                        if (i == 2 && j == 1)
                        {
                            if (textBox10.Text == "")
                            {
                                mat2 = false;
                            }
                        }
                        if (i == 2 && j == 2)
                        {
                            if (textBox11.Text == "")
                            {
                                mat2 = false;
                            }
                        }
                        if (i == 2 && j == 3)
                        {
                            if (textBox12.Text == "")
                            {
                                mat2 = false;
                            }
                        }
                        if (i == 3 && j == 0)
                        {
                            if (textBox13.Text == "")
                            {
                                mat2 = false;
                            }
                        }
                        if (i == 3 && j == 1)
                        {
                            if (textBox14.Text == "")
                            {
                                mat2 = false;
                            }
                        }
                        if (i == 3 && j == 2)
                        {
                            if (textBox15.Text == "")
                            {
                                mat2 = false;
                            }
                        }
                        if (i == 3 && j == 3)
                        {
                            if (textBox16.Text == "")
                            {
                                mat2 = false;
                            }
                        }
                    }
                }
                for (int i = 0; i < nu3; i++)
                {
                    for (int j = 0; j < nu4; j++)
                    {
                        if (i == 0 && j == 0)
                        {
                            if (textBox32.Text == "")
                            {
                                mat1 = false;
                            }
                        }
                        if (i == 0 && j == 1)
                        {
                            if (textBox31.Text == "")
                            {
                                mat1 = false;
                            }
                        }
                        if (i == 0 && j == 2)
                        {
                            if (textBox30.Text == "")
                            {
                                mat1 = false;
                            }
                        }
                        if (i == 0 && j == 3)
                        {
                            if (textBox29.Text == "")
                            {
                                mat1 = false;
                            }
                        }
                        if (i == 1 && j == 0)
                        {
                            if (textBox28.Text == "")
                            {
                                mat1 = false;
                            }
                        }
                        if (i == 1 && j == 1)
                        {
                            if (textBox27.Text == "")
                            {
                                mat1 = false;
                            }
                        }
                        if (i == 1 && j == 2)
                        {
                            if (textBox26.Text == "")
                            {
                                mat1 = false;
                            }
                        }
                        if (i == 1 && j == 3)
                        {
                            if (textBox25.Text == "")
                            {
                                mat1 = false;
                            }
                        }
                        if (i == 2 && j == 0)
                        {
                            if (textBox24.Text == "")
                            {
                                mat1 = false;
                            }
                        }
                        if (i == 2 && j == 1)
                        {
                            if (textBox23.Text == "")
                            {
                                mat1 = false;
                            }
                        }
                        if (i == 2 && j == 2)
                        {
                            if (textBox22.Text == "")
                            {
                                mat1 = false;
                            }
                        }
                        if (i == 2 && j == 3)
                        {
                            if (textBox21.Text == "")
                            {
                                mat1 = false;
                            }
                        }
                        if (i == 3 && j == 0)
                        {
                            if (textBox20.Text == "")
                            {
                                mat1 = false;
                            }
                        }
                        if (i == 3 && j == 1)
                        {
                            if (textBox19.Text == "")
                            {
                                mat1 = false;
                            }
                        }
                        if (i == 3 && j == 2)
                        {
                            if (textBox18.Text == "")
                            {
                                mat1 = false;
                            }
                        }
                        if (i == 3 && j == 3)
                        {
                            if (textBox17.Text == "")
                            {
                                mat2 = false;
                            }
                        }
                    }
                }
                if (mat1 == true && mat2 == true)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }
        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                if (provjera())
                {
                    label6.Visible = false;
                    label7.Visible = false;
                    label8.Visible = false;
                    label9.Visible = false;
                    label10.Visible = false;
                    label11.Visible = false;
                    label12.Visible = false;
                    label13.Visible = false;
                    label14.Visible = false;
                    label15.Visible = false;
                    label16.Visible = false;
                    label17.Visible = false;
                    label18.Visible = false;
                    label19.Visible = false;
                    label20.Visible = false;
                    label21.Visible = false;
                    int AduljinaJ = 0, AduljinaI = 0, BduljinaJ = 0, BduljinaI = 0;
                    float[,] matrica1 = new float[4, 4], matrica2 = new float[4, 4], matricaRJ = new float[4, 4];
                    if (textBox2.Text == "")
                    {
                        AduljinaJ = 1;
                    }
                    else if (textBox3.Text == "")
                    {
                        AduljinaJ = 2;
                    }
                    else if (textBox4.Text == "")
                    {
                        AduljinaJ = 3;
                    }
                    else
                    {
                        AduljinaJ = 4;
                    }
                    if (textBox5.Text == "")
                    {
                        AduljinaI = 1;
                    }
                    else if (textBox9.Text == "")
                    {
                        AduljinaI = 2;
                    }
                    else if (textBox13.Text == "")
                    {
                        AduljinaI = 3;
                    }
                    else
                    {
                        AduljinaI = 4;
                    }
                    for (int i = 0; i < AduljinaI; i++)
                    {
                        for (int j = 0; j < AduljinaJ; j++)
                        {
                            if (i == 0 && j == 0)
                            {
                                matrica1[i, j] = float.Parse(textBox1.Text);
                            }
                            if (i == 0 && j == 1)
                            {
                                matrica1[i, j] = float.Parse(textBox2.Text);
                            }
                            if (i == 0 && j == 2)
                            {
                                matrica1[i, j] = float.Parse(textBox3.Text);
                            }
                            if (i == 0 && j == 3)
                            {
                                matrica1[i, j] = float.Parse(textBox4.Text);
                            }
                            if (i == 1 && j == 0)
                            {
                                matrica1[i, j] = float.Parse(textBox5.Text);
                            }
                            if (i == 1 && j == 1)
                            {
                                matrica1[i, j] = float.Parse(textBox6.Text);
                            }
                            if (i == 1 && j == 2)
                            {
                                matrica1[i, j] = float.Parse(textBox7.Text);
                            }
                            if (i == 1 && j == 3)
                            {
                                matrica1[i, j] = float.Parse(textBox8.Text);
                            }
                            if (i == 2 && j == 0)
                            {
                                matrica1[i, j] = float.Parse(textBox9.Text);
                            }
                            if (i == 2 && j == 1)
                            {
                                matrica1[i, j] = float.Parse(textBox10.Text);
                            }
                            if (i == 2 && j == 2)
                            {
                                matrica1[i, j] = float.Parse(textBox11.Text);
                            }
                            if (i == 2 && j == 3)
                            {
                                matrica1[i, j] = float.Parse(textBox12.Text);
                            }
                            if (i == 3 && j == 0)
                            {
                                matrica1[i, j] = float.Parse(textBox13.Text);
                            }
                            if (i == 3 && j == 1)
                            {
                                matrica1[i, j] = float.Parse(textBox14.Text);
                            }
                            if (i == 3 && j == 2)
                            {
                                matrica1[i, j] = float.Parse(textBox15.Text);
                            }
                            if (i == 3 && j == 3)
                            {
                                matrica1[i, j] = float.Parse(textBox16.Text);
                            }
                        }
                    }
                    if (textBox31.Text == "")
                    {
                        BduljinaJ = 1;
                    }
                    else if (textBox30.Text == "")
                    {
                        BduljinaJ = 2;
                    }
                    else if (textBox29.Text == "")
                    {
                        BduljinaJ = 3;
                    }
                    else
                    {
                        BduljinaJ = 4;
                    }
                    if (textBox28.Text == "")
                    {
                        BduljinaI = 1;
                    }
                    else if (textBox24.Text == "")
                    {
                        BduljinaI = 2;
                    }
                    else if (textBox20.Text == "")
                    {
                        BduljinaI = 3;
                    }
                    else
                    {
                        BduljinaI = 4;
                    }
                    for (int i = 0; i < BduljinaI; i++)
                    {
                        for (int j = 0; j < BduljinaJ; j++)
                        {
                            if (i == 0 && j == 0)
                            {
                                matrica2[i, j] = float.Parse(textBox32.Text);
                            }
                            if (i == 0 && j == 1)
                            {
                                matrica2[i, j] = float.Parse(textBox31.Text);
                            }
                            if (i == 0 && j == 2)
                            {
                                matrica2[i, j] = float.Parse(textBox30.Text);
                            }
                            if (i == 0 && j == 3)
                            {
                                matrica2[i, j] = float.Parse(textBox29.Text);
                            }
                            if (i == 1 && j == 0)
                            {
                                matrica2[i, j] = float.Parse(textBox28.Text);
                            }
                            if (i == 1 && j == 1)
                            {
                                matrica2[i, j] = float.Parse(textBox27.Text);
                            }
                            if (i == 1 && j == 2)
                            {
                                matrica2[i, j] = float.Parse(textBox26.Text);
                            }
                            if (i == 1 && j == 3)
                            {
                                matrica2[i, j] = float.Parse(textBox25.Text);
                            }
                            if (i == 2 && j == 0)
                            {
                                matrica2[i, j] = float.Parse(textBox24.Text);
                            }
                            if (i == 2 && j == 1)
                            {
                                matrica2[i, j] = float.Parse(textBox23.Text);
                            }
                            if (i == 2 && j == 2)
                            {
                                matrica2[i, j] = float.Parse(textBox22.Text);
                            }
                            if (i == 2 && j == 3)
                            {
                                matrica2[i, j] = float.Parse(textBox21.Text);
                            }
                            if (i == 3 && j == 0)
                            {
                                matrica2[i, j] = float.Parse(textBox20.Text);
                            }
                            if (i == 3 && j == 1)
                            {
                                matrica2[i, j] = float.Parse(textBox19.Text);
                            }
                            if (i == 3 && j == 2)
                            {
                                matrica2[i, j] = float.Parse(textBox18.Text);
                            }
                            if (i == 3 && j == 3)
                            {
                                matrica2[i, j] = float.Parse(textBox17.Text);
                            }
                        }
                    }
                    for (int i = 0; i < AduljinaI; i++)
                    {
                        for (int j = 0; j < BduljinaJ; j++)
                        {
                            matricaRJ[i, j] = 0;
                            for (int k = 0; k < AduljinaJ; k++)
                            {
                                matricaRJ[i, j] += matrica1[i, k] * matrica2[k, j];
                            }
                        }
                    }
                    for (int i = 0; i < AduljinaI; i++)
                    {
                        for (int j = 0; j < BduljinaJ; j++)
                        {
                            if (i == 0 && j == 0)
                            {
                                label6.Visible = true;
                                label6.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 0 && j == 1)
                            {
                                label7.Visible = true;
                                label7.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 0 && j == 2)
                            {
                                label8.Visible = true;
                                label8.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 0 && j == 3)
                            {
                                label9.Visible = true;
                                label9.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 1 && j == 0)
                            {
                                label10.Visible = true;
                                label10.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 1 && j == 1)
                            {
                                label11.Visible = true;
                                label11.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 1 && j == 2)
                            {
                                label12.Visible = true;
                                label12.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 1 && j == 3)
                            {
                                label13.Visible = true;
                                label13.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 2 && j == 0)
                            {
                                label14.Visible = true;
                                label14.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 2 && j == 1)
                            {
                                label15.Visible = true;
                                label15.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 2 && j == 2)
                            {
                                label16.Visible = true;
                                label16.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 2 && j == 3)
                            {
                                label17.Visible = true;
                                label17.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 3 && j == 0)
                            {
                                label18.Visible = true;
                                label18.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 3 && j == 1)
                            {
                                label19.Visible = true;
                                label19.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 3 && j == 2)
                            {
                                label20.Visible = true;
                                label20.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 3 && j == 3)
                            {
                                label21.Visible = true;
                                label21.Text = matricaRJ[i, j].ToString();
                            }
                        }
                    }
                    label22.Visible = false;
                }
                else
                {
                    label6.Visible = false;
                    label7.Visible = false;
                    label8.Visible = false;
                    label9.Visible = false;
                    label10.Visible = false;
                    label11.Visible = false;
                    label12.Visible = false;
                    label13.Visible = false;
                    label14.Visible = false;
                    label15.Visible = false;
                    label16.Visible = false;
                    label17.Visible = false;
                    label18.Visible = false;
                    label19.Visible = false;
                    label20.Visible = false;
                    label21.Visible = false;
                    label22.Visible = true;
                }
            }
            catch
            {

            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                if (provjera())
                {
                    label6.Visible = false;
                    label7.Visible = false;
                    label8.Visible = false;
                    label9.Visible = false;
                    label10.Visible = false;
                    label11.Visible = false;
                    label12.Visible = false;
                    label13.Visible = false;
                    label14.Visible = false;
                    label15.Visible = false;
                    label16.Visible = false;
                    label17.Visible = false;
                    label18.Visible = false;
                    label19.Visible = false;
                    label20.Visible = false;
                    label21.Visible = false;
                    int AduljinaJ = 0, AduljinaI = 0, BduljinaJ = 0, BduljinaI = 0;
                    float[,] matrica1 = new float[4, 4], matrica2 = new float[4, 4], matricaRJ = new float[4, 4];
                    if (textBox2.Text == "")
                    {
                        BduljinaJ = 1;
                    }
                    else if (textBox3.Text == "")
                    {
                        BduljinaJ = 2;
                    }
                    else if (textBox4.Text == "")
                    {
                        BduljinaJ = 3;
                    }
                    else
                    {
                        BduljinaJ = 4;
                    }
                    if (textBox5.Text == "")
                    {
                        BduljinaI = 1;
                    }
                    else if (textBox9.Text == "")
                    {
                        BduljinaI = 2;
                    }
                    else if (textBox13.Text == "")
                    {
                        BduljinaI = 3;
                    }
                    else
                    {
                        BduljinaI = 4;
                    }
                    for (int i = 0; i < BduljinaI; i++)
                    {
                        for (int j = 0; j < BduljinaJ; j++)
                        {
                            if (i == 0 && j == 0)
                            {
                                matrica2[i, j] = float.Parse(textBox1.Text);
                            }
                            if (i == 0 && j == 1)
                            {
                                matrica2[i, j] = float.Parse(textBox2.Text);
                            }
                            if (i == 0 && j == 2)
                            {
                                matrica2[i, j] = float.Parse(textBox3.Text);
                            }
                            if (i == 0 && j == 3)
                            {
                                matrica2[i, j] = float.Parse(textBox4.Text);
                            }
                            if (i == 1 && j == 0)
                            {
                                matrica2[i, j] = float.Parse(textBox5.Text);
                            }
                            if (i == 1 && j == 1)
                            {
                                matrica2[i, j] = float.Parse(textBox6.Text);
                            }
                            if (i == 1 && j == 2)
                            {
                                matrica2[i, j] = float.Parse(textBox7.Text);
                            }
                            if (i == 1 && j == 3)
                            {
                                matrica2[i, j] = float.Parse(textBox8.Text);
                            }
                            if (i == 2 && j == 0)
                            {
                                matrica2[i, j] = float.Parse(textBox9.Text);
                            }
                            if (i == 2 && j == 1)
                            {
                                matrica2[i, j] = float.Parse(textBox10.Text);
                            }
                            if (i == 2 && j == 2)
                            {
                                matrica2[i, j] = float.Parse(textBox11.Text);
                            }
                            if (i == 2 && j == 3)
                            {
                                matrica2[i, j] = float.Parse(textBox12.Text);
                            }
                            if (i == 3 && j == 0)
                            {
                                matrica2[i, j] = float.Parse(textBox13.Text);
                            }
                            if (i == 3 && j == 1)
                            {
                                matrica2[i, j] = float.Parse(textBox14.Text);
                            }
                            if (i == 3 && j == 2)
                            {
                                matrica2[i, j] = float.Parse(textBox15.Text);
                            }
                            if (i == 3 && j == 3)
                            {
                                matrica2[i, j] = float.Parse(textBox16.Text);
                            }
                        }
                    }
                    if (textBox31.Text == "")
                    {
                        AduljinaJ = 1;
                    }
                    else if (textBox30.Text == "")
                    {
                        AduljinaJ = 2;
                    }
                    else if (textBox29.Text == "")
                    {
                        AduljinaJ = 3;
                    }
                    else
                    {
                        AduljinaJ = 4;
                    }
                    if (textBox28.Text == "")
                    {
                        AduljinaI = 1;
                    }
                    else if (textBox24.Text == "")
                    {
                        AduljinaI = 2;
                    }
                    else if (textBox20.Text == "")
                    {
                        AduljinaI = 3;
                    }
                    else
                    {
                        AduljinaI = 4;
                    }
                    for (int i = 0; i < AduljinaI; i++)
                    {
                        for (int j = 0; j < AduljinaJ; j++)
                        {
                            if (i == 0 && j == 0)
                            {
                                matrica1[i, j] = float.Parse(textBox32.Text);
                            }
                            if (i == 0 && j == 1)
                            {
                                matrica1[i, j] = float.Parse(textBox31.Text);
                            }
                            if (i == 0 && j == 2)
                            {
                                matrica1[i, j] = float.Parse(textBox30.Text);
                            }
                            if (i == 0 && j == 3)
                            {
                                matrica1[i, j] = float.Parse(textBox29.Text);
                            }
                            if (i == 1 && j == 0)
                            {
                                matrica1[i, j] = float.Parse(textBox28.Text);
                            }
                            if (i == 1 && j == 1)
                            {
                                matrica1[i, j] = float.Parse(textBox27.Text);
                            }
                            if (i == 1 && j == 2)
                            {
                                matrica1[i, j] = float.Parse(textBox26.Text);
                            }
                            if (i == 1 && j == 3)
                            {
                                matrica1[i, j] = float.Parse(textBox25.Text);
                            }
                            if (i == 2 && j == 0)
                            {
                                matrica1[i, j] = float.Parse(textBox24.Text);
                            }
                            if (i == 2 && j == 1)
                            {
                                matrica1[i, j] = float.Parse(textBox23.Text);
                            }
                            if (i == 2 && j == 2)
                            {
                                matrica1[i, j] = float.Parse(textBox22.Text);
                            }
                            if (i == 2 && j == 3)
                            {
                                matrica1[i, j] = float.Parse(textBox21.Text);
                            }
                            if (i == 3 && j == 0)
                            {
                                matrica1[i, j] = float.Parse(textBox20.Text);
                            }
                            if (i == 3 && j == 1)
                            {
                                matrica1[i, j] = float.Parse(textBox19.Text);
                            }
                            if (i == 3 && j == 2)
                            {
                                matrica1[i, j] = float.Parse(textBox18.Text);
                            }
                            if (i == 3 && j == 3)
                            {
                                matrica1[i, j] = float.Parse(textBox17.Text);
                            }
                        }
                    }
                    for (int i = 0; i < AduljinaI; i++)
                    {
                        for (int j = 0; j < BduljinaJ; j++)
                        {
                            matricaRJ[i, j] = 0;
                            for (int k = 0; k < AduljinaJ; k++)
                            {
                                matricaRJ[i, j] += matrica1[i, k] * matrica2[k, j];
                            }
                        }
                    }

                    for (int i = 0; i < AduljinaI; i++)
                    {
                        for (int j = 0; j < BduljinaJ; j++)
                        {
                            if (i == 0 && j == 0)
                            {
                                label6.Visible = true;
                                label6.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 0 && j == 1)
                            {
                                label7.Visible = true;
                                label7.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 0 && j == 2)
                            {
                                label8.Visible = true;
                                label8.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 0 && j == 3)
                            {
                                label9.Visible = true;
                                label9.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 1 && j == 0)
                            {
                                label10.Visible = true;
                                label10.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 1 && j == 1)
                            {
                                label11.Visible = true;
                                label11.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 1 && j == 2)
                            {
                                label12.Visible = true;
                                label12.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 1 && j == 3)
                            {
                                label13.Visible = true;
                                label13.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 2 && j == 0)
                            {
                                label14.Visible = true;
                                label14.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 2 && j == 1)
                            {
                                label15.Visible = true;
                                label15.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 2 && j == 2)
                            {
                                label16.Visible = true;
                                label16.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 2 && j == 3)
                            {
                                label17.Visible = true;
                                label17.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 3 && j == 0)
                            {
                                label18.Visible = true;
                                label18.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 3 && j == 1)
                            {
                                label19.Visible = true;
                                label19.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 3 && j == 2)
                            {
                                label20.Visible = true;
                                label20.Text = matricaRJ[i, j].ToString();
                            }
                            if (i == 3 && j == 3)
                            {
                                label21.Visible = true;
                                label21.Text = matricaRJ[i, j].ToString();
                            }
                        }
                    }
                    label22.Visible = false;
                }
                else
                {
                    label6.Visible = false;
                    label7.Visible = false;
                    label8.Visible = false;
                    label9.Visible = false;
                    label10.Visible = false;
                    label11.Visible = false;
                    label12.Visible = false;
                    label13.Visible = false;
                    label14.Visible = false;
                    label15.Visible = false;
                    label16.Visible = false;
                    label17.Visible = false;
                    label18.Visible = false;
                    label19.Visible = false;
                    label20.Visible = false;
                    label21.Visible = false;
                    label22.Visible = true;
                }
            }
            catch
            {

            }
        }

        private void restartToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {

                Process.Start(Path.GetFileNameWithoutExtension(Application.ExecutablePath));
                Environment.Exit(0);
            }
            catch
            {

            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void randomizirajToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Random ran = new Random();
            if (numericUpDown5.Value == 2)
            {
                numericUpDown1.Value = ran.Next(2, 5);
                numericUpDown2.Value = ran.Next(2, 5);
                numericUpDown3.Value = ran.Next(2, 5);
                numericUpDown4.Value = ran.Next(2, 5);
                button2.PerformClick();
            }
            else if (numericUpDown5.Value == 1)
            {
                numericUpDown1.Value = ran.Next(2, 5);
                numericUpDown2.Value = ran.Next(2, 5);
                button1.PerformClick();
            }
            else
            {
                ;
            }
        }
        int max = 10, min = -10;
        private void randomizirajBrojeveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Random ran = new Random();
            if (numericUpDown5.Value == 2)
            {
                button2.PerformClick();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox6.Text = "";
                textBox7.Text = "";
                textBox8.Text = "";
                textBox9.Text = "";
                textBox10.Text = "";
                textBox11.Text = "";
                textBox12.Text = "";
                textBox13.Text = "";
                textBox14.Text = "";
                textBox15.Text = "";
                textBox16.Text = "";
                if (numericUpDown1.Value == 2 && numericUpDown2.Value == 2)
                {
                    textBox1.Text = ran.Next(min, max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 3 && numericUpDown2.Value == 2)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox9.Text = ran.Next(min,max).ToString();
                    textBox10.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 4 && numericUpDown2.Value == 2)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox9.Text = ran.Next(min,max).ToString();
                    textBox10.Text = ran.Next(min,max).ToString();
                    textBox13.Text = ran.Next(min,max).ToString();
                    textBox14.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 2 && numericUpDown2.Value == 3)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox3.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox7.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 2 && numericUpDown2.Value == 4)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox3.Text = ran.Next(min,max).ToString();
                    textBox4.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox7.Text = ran.Next(min,max).ToString();
                    textBox8.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 3 && numericUpDown2.Value == 4)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox3.Text = ran.Next(min,max).ToString();
                    textBox4.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox7.Text = ran.Next(min,max).ToString();
                    textBox8.Text = ran.Next(min,max).ToString();
                    textBox9.Text = ran.Next(min,max).ToString();
                    textBox10.Text = ran.Next(min,max).ToString();
                    textBox11.Text = ran.Next(min,max).ToString();
                    textBox12.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 4 && numericUpDown2.Value == 3)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox3.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox7.Text = ran.Next(min,max).ToString();
                    textBox9.Text = ran.Next(min,max).ToString();
                    textBox10.Text = ran.Next(min,max).ToString();
                    textBox11.Text = ran.Next(min,max).ToString();
                    textBox13.Text = ran.Next(min,max).ToString();
                    textBox14.Text = ran.Next(min,max).ToString();
                    textBox15.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 3 && numericUpDown2.Value == 3)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox3.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox7.Text = ran.Next(min,max).ToString();
                    textBox9.Text = ran.Next(min,max).ToString();
                    textBox10.Text = ran.Next(min,max).ToString();
                    textBox11.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 4 && numericUpDown2.Value == 4)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox3.Text = ran.Next(min,max).ToString();
                    textBox4.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox7.Text = ran.Next(min,max).ToString();
                    textBox8.Text = ran.Next(min,max).ToString();
                    textBox9.Text = ran.Next(min,max).ToString();
                    textBox10.Text = ran.Next(min,max).ToString();
                    textBox11.Text = ran.Next(min,max).ToString();
                    textBox12.Text = ran.Next(min,max).ToString();
                    textBox13.Text = ran.Next(min,max).ToString();
                    textBox14.Text = ran.Next(min,max).ToString();
                    textBox15.Text = ran.Next(min,max).ToString();
                    textBox16.Text = ran.Next(min,max).ToString();
                }
                textBox17.Text = "";
                textBox18.Text = "";
                textBox19.Text = "";
                textBox20.Text = "";
                textBox21.Text = "";
                textBox22.Text = "";
                textBox23.Text = "";
                textBox24.Text = "";
                textBox25.Text = "";
                textBox26.Text = "";
                textBox27.Text = "";
                textBox28.Text = "";
                textBox29.Text = "";
                textBox30.Text = "";
                textBox31.Text = "";
                textBox32.Text = "";
                if (numericUpDown3.Value == 2 && numericUpDown4.Value == 2)
                {
                    textBox32.Text = ran.Next(min,max).ToString();
                    textBox31.Text = ran.Next(min,max).ToString();
                    textBox28.Text = ran.Next(min,max).ToString();
                    textBox27.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown3.Value == 3 && numericUpDown4.Value == 2)
                {
                    textBox32.Text = ran.Next(min,max).ToString();
                    textBox31.Text = ran.Next(min,max).ToString();
                    textBox28.Text = ran.Next(min,max).ToString();
                    textBox27.Text = ran.Next(min,max).ToString();
                    textBox24.Text = ran.Next(min,max).ToString();
                    textBox23.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown3.Value == 4 && numericUpDown4.Value == 2)
                {
                    textBox32.Text = ran.Next(min,max).ToString();
                    textBox31.Text = ran.Next(min,max).ToString();
                    textBox28.Text = ran.Next(min,max).ToString();
                    textBox27.Text = ran.Next(min,max).ToString();
                    textBox24.Text = ran.Next(min,max).ToString();
                    textBox23.Text = ran.Next(min,max).ToString();
                    textBox20.Text = ran.Next(min,max).ToString();
                    textBox19.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown3.Value == 2 && numericUpDown4.Value == 3)
                {
                    textBox32.Text = ran.Next(min,max).ToString();
                    textBox31.Text = ran.Next(min,max).ToString();
                    textBox30.Text = ran.Next(min,max).ToString();
                    textBox28.Text = ran.Next(min,max).ToString();
                    textBox27.Text = ran.Next(min,max).ToString();
                    textBox26.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown3.Value == 2 && numericUpDown4.Value == 4)
                {
                    textBox32.Text = ran.Next(min,max).ToString();
                    textBox31.Text = ran.Next(min,max).ToString();
                    textBox30.Text = ran.Next(min,max).ToString();
                    textBox29.Text = ran.Next(min,max).ToString();
                    textBox28.Text = ran.Next(min,max).ToString();
                    textBox27.Text = ran.Next(min,max).ToString();
                    textBox26.Text = ran.Next(min,max).ToString();
                    textBox25.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown3.Value == 3 && numericUpDown4.Value == 4)
                {
                    textBox32.Text = ran.Next(min,max).ToString();
                    textBox31.Text = ran.Next(min,max).ToString();
                    textBox30.Text = ran.Next(min,max).ToString();
                    textBox29.Text = ran.Next(min,max).ToString();
                    textBox28.Text = ran.Next(min,max).ToString();
                    textBox27.Text = ran.Next(min,max).ToString();
                    textBox26.Text = ran.Next(min,max).ToString();
                    textBox25.Text = ran.Next(min,max).ToString();
                    textBox24.Text = ran.Next(min,max).ToString();
                    textBox23.Text = ran.Next(min,max).ToString();
                    textBox22.Text = ran.Next(min,max).ToString();
                    textBox21.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown3.Value == 4 && numericUpDown4.Value == 3)
                {
                    textBox32.Text = ran.Next(min,max).ToString();
                    textBox31.Text = ran.Next(min,max).ToString();
                    textBox30.Text = ran.Next(min,max).ToString();
                    textBox28.Text = ran.Next(min,max).ToString();
                    textBox27.Text = ran.Next(min,max).ToString();
                    textBox26.Text = ran.Next(min,max).ToString();
                    textBox24.Text = ran.Next(min,max).ToString();
                    textBox23.Text = ran.Next(min,max).ToString();
                    textBox22.Text = ran.Next(min,max).ToString();
                    textBox20.Text = ran.Next(min,max).ToString();
                    textBox19.Text = ran.Next(min,max).ToString();
                    textBox18.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown3.Value == 3 && numericUpDown4.Value == 3)
                {
                    textBox32.Text = ran.Next(min,max).ToString();
                    textBox31.Text = ran.Next(min,max).ToString();
                    textBox30.Text = ran.Next(min,max).ToString();
                    textBox28.Text = ran.Next(min,max).ToString();
                    textBox27.Text = ran.Next(min,max).ToString();
                    textBox26.Text = ran.Next(min,max).ToString();
                    textBox24.Text = ran.Next(min,max).ToString();
                    textBox23.Text = ran.Next(min,max).ToString();
                    textBox22.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown3.Value == 4 && numericUpDown4.Value == 4)
                {
                    textBox32.Text = ran.Next(min,max).ToString();
                    textBox31.Text = ran.Next(min,max).ToString();
                    textBox30.Text = ran.Next(min,max).ToString();
                    textBox29.Text = ran.Next(min,max).ToString();
                    textBox28.Text = ran.Next(min,max).ToString();
                    textBox27.Text = ran.Next(min,max).ToString();
                    textBox26.Text = ran.Next(min,max).ToString();
                    textBox25.Text = ran.Next(min,max).ToString();
                    textBox24.Text = ran.Next(min,max).ToString();
                    textBox23.Text = ran.Next(min,max).ToString();
                    textBox22.Text = ran.Next(min,max).ToString();
                    textBox21.Text = ran.Next(min,max).ToString();
                    textBox20.Text = ran.Next(min,max).ToString();
                    textBox19.Text = ran.Next(min,max).ToString();
                    textBox18.Text = ran.Next(min,max).ToString();
                    textBox17.Text = ran.Next(min,max).ToString();
                }
            }
            else if (numericUpDown5.Value == 1)
            {

                button1.PerformClick();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox6.Text = "";
                textBox7.Text = "";
                textBox8.Text = "";
                textBox9.Text = "";
                textBox10.Text = "";
                textBox11.Text = "";
                textBox12.Text = "";
                textBox13.Text = "";
                textBox14.Text = "";
                textBox15.Text = "";
                textBox16.Text = "";
                if (numericUpDown1.Value == 2 && numericUpDown2.Value == 2)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 3 && numericUpDown2.Value == 2)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox9.Text = ran.Next(min,max).ToString();
                    textBox10.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 4 && numericUpDown2.Value == 2)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox9.Text = ran.Next(min,max).ToString();
                    textBox10.Text = ran.Next(min,max).ToString();
                    textBox13.Text = ran.Next(min,max).ToString();
                    textBox14.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 2 && numericUpDown2.Value == 3)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox3.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox7.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 2 && numericUpDown2.Value == 4)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox3.Text = ran.Next(min,max).ToString();
                    textBox4.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox7.Text = ran.Next(min,max).ToString();
                    textBox8.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 3 && numericUpDown2.Value == 4)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox3.Text = ran.Next(min,max).ToString();
                    textBox4.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox7.Text = ran.Next(min,max).ToString();
                    textBox8.Text = ran.Next(min,max).ToString();
                    textBox9.Text = ran.Next(min,max).ToString();
                    textBox10.Text = ran.Next(min,max).ToString();
                    textBox11.Text = ran.Next(min,max).ToString();
                    textBox12.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 4 && numericUpDown2.Value == 3)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox3.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox7.Text = ran.Next(min,max).ToString();
                    textBox9.Text = ran.Next(min,max).ToString();
                    textBox10.Text = ran.Next(min,max).ToString();
                    textBox11.Text = ran.Next(min,max).ToString();
                    textBox13.Text = ran.Next(min,max).ToString();
                    textBox14.Text = ran.Next(min,max).ToString();
                    textBox15.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 3 && numericUpDown2.Value == 3)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox3.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox7.Text = ran.Next(min,max).ToString();
                    textBox9.Text = ran.Next(min,max).ToString();
                    textBox10.Text = ran.Next(min,max).ToString();
                    textBox11.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 4 && numericUpDown2.Value == 4)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox3.Text = ran.Next(min,max).ToString();
                    textBox4.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox7.Text = ran.Next(min,max).ToString();
                    textBox8.Text = ran.Next(min,max).ToString();
                    textBox9.Text = ran.Next(min,max).ToString();
                    textBox10.Text = ran.Next(min,max).ToString();
                    textBox11.Text = ran.Next(min,max).ToString();
                    textBox12.Text = ran.Next(min,max).ToString();
                    textBox13.Text = ran.Next(min,max).ToString();
                    textBox14.Text = ran.Next(min,max).ToString();
                    textBox15.Text = ran.Next(min,max).ToString();
                    textBox16.Text = ran.Next(min,max).ToString();
                }
            }
            else
            {
                ;
            }
        }

        private void postaviMinIMaxVrijednostiUMatricamaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox33.Visible = true;
            textBox34.Visible = true;
            button8.Visible = true;
            label25.Visible = true;
            label26.Visible = true;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            try
            {
                min = int.Parse(textBox33.Text);
                max = int.Parse(textBox34.Text)+1;
                textBox33.Visible = false;
                textBox34.Visible = false;
                button8.Visible = false;
                label25.Visible = false;
                label26.Visible = false;
            }
            catch
            {

            }
        }
        float det = 0;
        private void button9_Click(object sender, EventArgs e)
        {
            try
            {
                int AduljinaJ = 0, AduljinaI = 0;
                float[,] matrica1 = new float[4, 4];
                if (textBox2.Text == "")
                {
                    AduljinaJ = 1;
                }
                else if (textBox3.Text == "")
                {
                    AduljinaJ = 2;
                }
                else if (textBox4.Text == "")
                {
                    AduljinaJ = 3;
                }
                else
                {
                    AduljinaJ = 4;
                }
                if (textBox5.Text == "")
                {
                    AduljinaI = 1;
                }
                else if (textBox9.Text == "")
                {
                    AduljinaI = 2;
                }
                else if (textBox13.Text == "")
                {
                    AduljinaI = 3;
                }
                else
                {
                    AduljinaI = 4;
                }
                for (int i = 0; i < AduljinaI; i++)
                {
                    for (int j = 0; j < AduljinaJ; j++)
                    {
                        if (i == 0 && j == 0)
                        {
                            matrica1[i, j] = float.Parse(textBox1.Text);
                        }
                        if (i == 0 && j == 1)
                        {
                            matrica1[i, j] = float.Parse(textBox2.Text);
                        }
                        if (i == 0 && j == 2)
                        {
                            matrica1[i, j] = float.Parse(textBox3.Text);
                        }
                        if (i == 0 && j == 3)
                        {
                            matrica1[i, j] = float.Parse(textBox4.Text);
                        }
                        if (i == 1 && j == 0)
                        {
                            matrica1[i, j] = float.Parse(textBox5.Text);
                        }
                        if (i == 1 && j == 1)
                        {
                            matrica1[i, j] = float.Parse(textBox6.Text);
                        }
                        if (i == 1 && j == 2)
                        {
                            matrica1[i, j] = float.Parse(textBox7.Text);
                        }
                        if (i == 1 && j == 3)
                        {
                            matrica1[i, j] = float.Parse(textBox8.Text);
                        }
                        if (i == 2 && j == 0)
                        {
                            matrica1[i, j] = float.Parse(textBox9.Text);
                        }
                        if (i == 2 && j == 1)
                        {
                            matrica1[i, j] = float.Parse(textBox10.Text);
                        }
                        if (i == 2 && j == 2)
                        {
                            matrica1[i, j] = float.Parse(textBox11.Text);
                        }
                        if (i == 2 && j == 3)
                        {
                            matrica1[i, j] = float.Parse(textBox12.Text);
                        }
                        if (i == 3 && j == 0)
                        {
                            matrica1[i, j] = float.Parse(textBox13.Text);
                        }
                        if (i == 3 && j == 1)
                        {
                            matrica1[i, j] = float.Parse(textBox14.Text);
                        }
                        if (i == 3 && j == 2)
                        {
                            matrica1[i, j] = float.Parse(textBox15.Text);
                        }
                        if (i == 3 && j == 3)
                        {
                            matrica1[i, j] = float.Parse(textBox16.Text);
                        }
                    }
                }
                if (numericUpDown1.Value == 2)
                {
                    if (!(textBox1.Text == "" || textBox2.Text == "" || textBox5.Text == "" || textBox6.Text == ""))
                    {
                        label28.Text = "";
                        label27.Visible = true;
                        label28.Visible = true;
                        float det1 = float.Parse(textBox1.Text) * float.Parse(textBox6.Text), det2 = float.Parse(textBox2.Text) * float.Parse(textBox5.Text);
                        det = det1 - det2;
                        label28.Text = det.ToString();
                        label22.Visible = false;
                    }
                    else
                    {
                        label27.Visible = false;
                        label28.Visible = false;
                        label22.Visible = true;
                    }
                }
                else if (numericUpDown1.Value == 3)
                {
                    if (!(textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox7.Text == "" || textBox9.Text == "" || textBox10.Text == "" || textBox11.Text == ""))
                    {
                        label28.Text = "";
                        label27.Visible = true;
                        label28.Visible = true;
                        det=0;
                        for (int i = 0; i < 3; i++)
                        {
                            det = det + (matrica1[0, i] * (matrica1[1, (i + 1) % 3] * matrica1[2, (i + 2) % 3] - matrica1[1, (i + 2) % 3] * matrica1[2, (i + 1) % 3]));
                        }
                        label28.Text = det.ToString();
                        label22.Visible = false;
                    }
                    else
                    {
                        label27.Visible = false;
                        label28.Visible = false;
                        label22.Visible = true;
                    }
                }
                else if (numericUpDown1.Value == 4)
                {
                    if (!(textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox7.Text == "" || textBox8.Text == "" || textBox9.Text == "" || textBox10.Text == "" || textBox11.Text == "" || textBox12.Text == "" || textBox13.Text == "" || textBox4.Text == "" || textBox15.Text == "" || textBox16.Text == ""))
                    {
                        label28.Text = "";
                        label27.Visible = true;
                        label28.Visible = true;
                        det = 0;
                        det = matrica1[0, 3] * matrica1[1, 2] * matrica1[2, 1] * matrica1[3, 0] - matrica1[0, 2] * matrica1[1, 3] * matrica1[2, 1] * matrica1[3, 0] -
                         matrica1[0, 3] * matrica1[1, 1] * matrica1[2, 2] * matrica1[3, 0] + matrica1[0, 1] * matrica1[1, 3] * matrica1[2, 2] * matrica1[3, 0] +
                         matrica1[0, 2] * matrica1[1, 1] * matrica1[2, 3] * matrica1[3, 0] - matrica1[0, 1] * matrica1[1, 2] * matrica1[2, 3] * matrica1[3, 0] -
                         matrica1[0, 3] * matrica1[1, 2] * matrica1[2, 0] * matrica1[3, 1] + matrica1[0, 2] * matrica1[1, 3] * matrica1[2, 0] * matrica1[3, 1] +
                         matrica1[0, 3] * matrica1[1, 0] * matrica1[2, 2] * matrica1[3, 1] - matrica1[0, 0] * matrica1[1, 3] * matrica1[2, 2] * matrica1[3, 1] -
                         matrica1[0, 2] * matrica1[1, 0] * matrica1[2, 3] * matrica1[3, 1] + matrica1[0, 0] * matrica1[1, 2] * matrica1[2, 3] * matrica1[3, 1] +
                         matrica1[0, 3] * matrica1[1, 1] * matrica1[2, 0] * matrica1[3, 2] - matrica1[0, 1] * matrica1[1, 3] * matrica1[2, 0] * matrica1[3, 2] -
                         matrica1[0, 3] * matrica1[1, 0] * matrica1[2, 1] * matrica1[3, 2] + matrica1[0, 0] * matrica1[1, 3] * matrica1[2, 1] * matrica1[3, 2] +
                         matrica1[0, 1] * matrica1[1, 0] * matrica1[2, 3] * matrica1[3, 2] - matrica1[0, 0] * matrica1[1, 1] * matrica1[2, 3] * matrica1[3, 2] -
                         matrica1[0, 2] * matrica1[1, 1] * matrica1[2, 0] * matrica1[3, 3] + matrica1[0, 1] * matrica1[1, 2] * matrica1[2, 0] * matrica1[3, 3] +
                         matrica1[0, 2] * matrica1[1, 0] * matrica1[2, 1] * matrica1[3, 3] - matrica1[0, 0] * matrica1[1, 2] * matrica1[2, 1] * matrica1[3, 3] -
                         matrica1[0, 1] * matrica1[1, 0] * matrica1[2, 2] * matrica1[3, 3] + matrica1[0, 0] * matrica1[1, 1] * matrica1[2, 2] * matrica1[3, 3];
                        label28.Text = det.ToString();
                        label22.Visible = false;
                    }
                    else
                    {
                        label27.Visible = false;
                        label28.Visible = false;
                        label22.Visible = true;
                    }
                    
                }
            }
            catch
            {

            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            try
            {
                int AduljinaJ = 0, AduljinaI = 0;
                float[,] matrica1 = new float[4, 4];
                if (textBox2.Text == "")
                {
                    AduljinaJ = 1;
                }
                else if (textBox3.Text == "")
                {
                    AduljinaJ = 2;
                }
                else if (textBox4.Text == "")
                {
                    AduljinaJ = 3;
                }
                else
                {
                    AduljinaJ = 4;
                }
                if (textBox5.Text == "")
                {
                    AduljinaI = 1;
                }
                else if (textBox9.Text == "")
                {
                    AduljinaI = 2;
                }
                else if (textBox13.Text == "")
                {
                    AduljinaI = 3;
                }
                else
                {
                    AduljinaI = 4;
                }
                for (int i = 0; i < AduljinaI; i++)
                {
                    for (int j = 0; j < AduljinaJ; j++)
                    {
                        if (i == 0 && j == 0)
                        {
                            matrica1[i, j] = float.Parse(textBox1.Text);
                        }
                        if (i == 0 && j == 1)
                        {
                            matrica1[i, j] = float.Parse(textBox2.Text);
                        }
                        if (i == 0 && j == 2)
                        {
                            matrica1[i, j] = float.Parse(textBox3.Text);
                        }
                        if (i == 0 && j == 3)
                        {
                            matrica1[i, j] = float.Parse(textBox4.Text);
                        }
                        if (i == 1 && j == 0)
                        {
                            matrica1[i, j] = float.Parse(textBox5.Text);
                        }
                        if (i == 1 && j == 1)
                        {
                            matrica1[i, j] = float.Parse(textBox6.Text);
                        }
                        if (i == 1 && j == 2)
                        {
                            matrica1[i, j] = float.Parse(textBox7.Text);
                        }
                        if (i == 1 && j == 3)
                        {
                            matrica1[i, j] = float.Parse(textBox8.Text);
                        }
                        if (i == 2 && j == 0)
                        {
                            matrica1[i, j] = float.Parse(textBox9.Text);
                        }
                        if (i == 2 && j == 1)
                        {
                            matrica1[i, j] = float.Parse(textBox10.Text);
                        }
                        if (i == 2 && j == 2)
                        {
                            matrica1[i, j] = float.Parse(textBox11.Text);
                        }
                        if (i == 2 && j == 3)
                        {
                            matrica1[i, j] = float.Parse(textBox12.Text);
                        }
                        if (i == 3 && j == 0)
                        {
                            matrica1[i, j] = float.Parse(textBox13.Text);
                        }
                        if (i == 3 && j == 1)
                        {
                            matrica1[i, j] = float.Parse(textBox14.Text);
                        }
                        if (i == 3 && j == 2)
                        {
                            matrica1[i, j] = float.Parse(textBox15.Text);
                        }
                        if (i == 3 && j == 3)
                        {
                            matrica1[i, j] = float.Parse(textBox16.Text);
                        }
                    }
                }
                if (numericUpDown1.Value == 2)
                {
                    label29.Visible = false;
                    float[,] matricaRJ = new float[2, 2], m1 = new float[2, 2];
                    button9.PerformClick();
                    m1[0, 0] = matrica1[1,1];
                    m1[0, 1] = -1*matrica1[0, 1];
                    m1[1, 0] = -1 * matrica1[1, 0];
                    m1[1, 1] = matrica1[0, 0];
                    float c5 = 1 / det;
                    for(int i = 0; i < 2; i++)
                    {
                        for(int j = 0; j < 2; j++)
                        {
                            matricaRJ[i, j] = c5*m1[i, j];
                        }
                    }
                    if (det == 0)
                    {
                        label29.Visible = true;
                    }
                    else
                    {
                        label29.Visible = false;
                        label6.Visible = true;
                        label7.Visible = true;
                        label8.Visible = false;
                        label9.Visible = false;
                        label10.Visible = true;
                        label11.Visible = true;
                        label12.Visible = false;
                        label13.Visible = false;
                        label14.Visible = false;
                        label15.Visible = false;
                        label16.Visible = false;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        label6.Text = matricaRJ[0, 0].ToString("0.00");
                        label7.Text = matricaRJ[0, 1].ToString("0.00");
                        label10.Text = matricaRJ[1, 0].ToString("0.00");
                        label11.Text = matricaRJ[1, 1].ToString("0.00");
                    }
                    
                }
                else if (numericUpDown1.Value == 3)
                {
                    label29.Visible = false;
                    float[,] matricaRJ = new float[4, 4],m1=new float[2,2], m2 = new float[2, 2], m3 = new float[2, 2], m4 = new float[2, 2], m5 = new float[2, 2], m6 = new float[2, 2], m7 = new float[2, 2], m8 = new float[2, 2], m9 = new float[2, 2],matrica=new float[3,3];
                    m1[0, 0] =matrica1[1,1];
                    m1[0, 1] = matrica1[1, 2];
                    m1[1, 0] = matrica1[2, 1];
                    m1[1, 1] = matrica1[2, 2];
                    m2[0, 0] = matrica1[1, 0];
                    m2[0, 1] = matrica1[1, 2];
                    m2[1, 0] = matrica1[2, 0];
                    m2[1, 1] = matrica1[2, 2];
                    m3[0, 0] = matrica1[1, 0];
                    m3[0, 1] = matrica1[1, 1];
                    m3[1, 0] = matrica1[2, 0];
                    m3[1, 1] = matrica1[2, 1];
                    m4[0, 0] = matrica1[0, 1];
                    m4[0, 1] = matrica1[0, 2];
                    m4[1, 0] = matrica1[2, 1];
                    m4[1, 1] = matrica1[2, 2];
                    m5[0, 0] = matrica1[0, 0];
                    m5[0, 1] = matrica1[0, 2];
                    m5[1, 0] = matrica1[2, 0];
                    m5[1, 1] = matrica1[2, 2];
                    m6[0, 0] = matrica1[0, 0];
                    m6[0, 1] = matrica1[0, 1];
                    m6[1, 0] = matrica1[2, 0];
                    m6[1, 1] = matrica1[2, 1];
                    m7[0, 0] = matrica1[0, 1];
                    m7[0, 1] = matrica1[0, 2];
                    m7[1, 0] = matrica1[1, 1];
                    m7[1, 1] = matrica1[1, 2];
                    m8[0, 0] = matrica1[0, 0];
                    m8[0, 1] = matrica1[0, 2];
                    m8[1, 0] = matrica1[1, 0];
                    m8[1, 1] = matrica1[1, 2];
                    m9[0, 0] = matrica1[0, 0];
                    m9[0, 1] = matrica1[0, 1];
                    m9[1, 0] = matrica1[1, 0];
                    m9[1, 1] = matrica1[1, 1];
                    matrica[0, 0] = de(m1);
                    matrica[1, 0] = -1*de(m2);
                    matrica[2, 0] = de(m3);
                    matrica[0, 1] = -1 * de(m4);
                    matrica[1, 1] = de(m5);
                    matrica[2, 1] = -1*de(m6);
                    matrica[0, 2] = de(m7);
                    matrica[1, 2] = -1*de(m8);
                    matrica[2, 2] = de(m9);
                    button9.PerformClick();
                    if (det == 0)
                    {
                        label29.Visible = true;
                    }
                    else
                    {
                        float c5 = 1 / det;
                        for (int i = 0; i < 3; i++)
                        {
                            for (int j = 0; j < 3; j++)
                            {
                                matricaRJ[i, j] = c5 * matrica[i, j];
                            }
                        }
                        label29.Visible = false;
                        label6.Visible = true;
                        label7.Visible = true;
                        label8.Visible = true;
                        label9.Visible = false;
                        label10.Visible = true;
                        label11.Visible = true;
                        label12.Visible = true;
                        label13.Visible = false;
                        label14.Visible = true;
                        label15.Visible = true;
                        label16.Visible = true;
                        label17.Visible = false;
                        label18.Visible = false;
                        label19.Visible = false;
                        label20.Visible = false;
                        label21.Visible = false;
                        label6.Text = matricaRJ[0, 0].ToString("0.00");
                        label7.Text = matricaRJ[0, 1].ToString("0.00");
                        label8.Text = matricaRJ[0, 2].ToString("0.00");
                        label10.Text = matricaRJ[1, 0].ToString("0.00");
                        label11.Text = matricaRJ[1, 1].ToString("0.00");
                        label12.Text = matricaRJ[1, 2].ToString("0.00");
                        label14.Text = matricaRJ[2, 0].ToString("0.00");
                        label15.Text = matricaRJ[2, 1].ToString("0.00");
                        label16.Text = matricaRJ[2, 2].ToString("0.00");
                    }
                    
                }
                else if (numericUpDown1.Value == 4)
                {
                    label29.Visible = false;
                    float[,] matricaRJ = new float[4, 4], m1 = new float[3, 3], m2 = new float[3, 3], m3 = new float[3, 3], m4 = new float[3, 3], m5 = new float[3, 3], m6 = new float[3, 3], m7 = new float[3, 3], m8 = new float[3, 3], m9 = new float[3, 3], m10 = new float[3, 3], m11 = new float[3, 3], m12 = new float[3, 3], m13 = new float[3, 3], m14 = new float[3, 3], m15 = new float[3, 3], m16 = new float[3, 3], matrica = new float[4, 4];
                    m1[0, 0] = matrica1[1, 1];
                    m1[0, 1] = matrica1[1, 2];
                    m1[0, 2] = matrica1[1, 3];
                    m1[1, 0] = matrica1[2, 1];
                    m1[1, 1] = matrica1[2, 2];
                    m1[1, 2] = matrica1[2, 3];
                    m1[2, 0] = matrica1[3, 1];
                    m1[2, 1] = matrica1[3, 2];
                    m1[2, 2] = matrica1[3, 3];
                    m2[0, 0] = matrica1[1, 0];
                    m2[0, 1] = matrica1[1, 2];
                    m2[0, 2] = matrica1[1, 3];
                    m2[1, 0] = matrica1[2, 0];
                    m2[1, 1] = matrica1[2, 2];
                    m2[1, 2] = matrica1[2, 3];
                    m2[2, 0] = matrica1[3, 0];
                    m2[2, 1] = matrica1[3, 2];
                    m2[2, 2] = matrica1[3, 3];
                    m3[0, 0] = matrica1[1, 0];
                    m3[0, 1] = matrica1[1, 1];
                    m3[0, 2] = matrica1[1, 3];
                    m3[1, 0] = matrica1[2, 0];
                    m3[1, 1] = matrica1[2, 1];
                    m3[1, 2] = matrica1[2, 3];
                    m3[2, 0] = matrica1[3, 0];
                    m3[2, 1] = matrica1[3, 1];
                    m3[2, 2] = matrica1[3, 3];
                    m4[0, 0] = matrica1[1, 0];
                    m4[0, 1] = matrica1[1, 1];
                    m4[0, 2] = matrica1[1, 2];
                    m4[1, 0] = matrica1[2, 0];
                    m4[1, 1] = matrica1[2, 1];
                    m4[1, 2] = matrica1[2, 2];
                    m4[2, 0] = matrica1[3, 0];
                    m4[2, 1] = matrica1[3, 1];
                    m4[2, 2] = matrica1[3, 2];
                    m5[0, 0] = matrica1[0, 1];
                    m5[0, 1] = matrica1[0, 2];
                    m5[0, 2] = matrica1[0, 3];
                    m5[1, 0] = matrica1[2, 1];
                    m5[1, 1] = matrica1[2, 2];
                    m5[1, 2] = matrica1[2, 3];
                    m5[2, 0] = matrica1[3, 1];
                    m5[2, 1] = matrica1[3, 2];
                    m5[2, 2] = matrica1[3, 3];
                    m6[0, 0] = matrica1[0, 0];
                    m6[0, 1] = matrica1[0, 2];
                    m6[0, 2] = matrica1[0, 3];
                    m6[1, 0] = matrica1[2, 0];
                    m6[1, 1] = matrica1[2, 2];
                    m6[1, 2] = matrica1[2, 3];
                    m6[2, 0] = matrica1[3, 0];
                    m6[2, 1] = matrica1[3, 2];
                    m6[2, 2] = matrica1[3, 3];
                    m7[0, 0] = matrica1[0, 0];
                    m7[0, 1] = matrica1[0, 1];
                    m7[0, 2] = matrica1[0, 3];
                    m7[1, 0] = matrica1[2, 0];
                    m7[1, 1] = matrica1[2, 1];
                    m7[1, 2] = matrica1[2, 3];
                    m7[2, 0] = matrica1[3, 0];
                    m7[2, 1] = matrica1[3, 1];
                    m7[2, 2] = matrica1[3, 3];
                    m8[0, 0] = matrica1[0, 0];
                    m8[0, 1] = matrica1[0, 1];
                    m8[0, 2] = matrica1[0, 2];
                    m8[1, 0] = matrica1[2, 0];
                    m8[1, 1] = matrica1[2, 1];
                    m8[1, 2] = matrica1[2, 2];
                    m8[2, 0] = matrica1[3, 0];
                    m8[2, 1] = matrica1[3, 1];
                    m8[2, 2] = matrica1[3, 2];
                    m9[0, 0] = matrica1[0, 1];
                    m9[0, 1] = matrica1[0, 2];
                    m9[0, 2] = matrica1[0, 3];
                    m9[1, 0] = matrica1[1, 1];
                    m9[1, 1] = matrica1[1, 2];
                    m9[1, 2] = matrica1[1, 3];
                    m9[2, 0] = matrica1[3, 1];
                    m9[2, 1] = matrica1[3, 2];
                    m9[2, 2] = matrica1[3, 3];
                    m10[0, 0] = matrica1[0, 0];
                    m10[0, 1] = matrica1[0, 2];
                    m10[0, 2] = matrica1[0, 3];
                    m10[1, 0] = matrica1[1, 0];
                    m10[1, 1] = matrica1[1, 2];
                    m10[1, 2] = matrica1[1, 3];
                    m10[2, 0] = matrica1[3, 0];
                    m10[2, 1] = matrica1[3, 2];
                    m10[2, 2] = matrica1[3, 3];
                    m11[0, 0] = matrica1[0, 0];
                    m11[0, 1] = matrica1[0, 1];
                    m11[0, 2] = matrica1[0, 3];
                    m11[1, 0] = matrica1[1, 0];
                    m11[1, 1] = matrica1[1, 1];
                    m11[1, 2] = matrica1[1, 3];
                    m11[2, 0] = matrica1[3, 0];
                    m11[2, 1] = matrica1[3, 1];
                    m11[2, 2] = matrica1[3, 3];
                    m12[0, 0] = matrica1[0, 0];
                    m12[0, 1] = matrica1[0, 1];
                    m12[0, 2] = matrica1[0, 2];
                    m12[1, 0] = matrica1[1, 0];
                    m12[1, 1] = matrica1[1, 1];
                    m12[1, 2] = matrica1[1, 2];
                    m12[2, 0] = matrica1[3, 0];
                    m12[2, 1] = matrica1[3, 1];
                    m12[2, 2] = matrica1[3, 2];
                    m13[0, 0] = matrica1[0, 1];
                    m13[0, 1] = matrica1[0, 2];
                    m13[0, 2] = matrica1[0, 3];
                    m13[1, 0] = matrica1[1, 1];
                    m13[1, 1] = matrica1[1, 2];
                    m13[1, 2] = matrica1[1, 3];
                    m13[2, 0] = matrica1[2, 1];
                    m13[2, 1] = matrica1[2, 2];
                    m13[2, 2] = matrica1[2, 3];
                    m14[0, 0] = matrica1[0, 0];
                    m14[0, 1] = matrica1[0, 2];
                    m14[0, 2] = matrica1[0, 3];
                    m14[1, 0] = matrica1[1, 0];
                    m14[1, 1] = matrica1[1, 2];
                    m14[1, 2] = matrica1[1, 3];
                    m14[2, 0] = matrica1[2, 0];
                    m14[2, 1] = matrica1[2, 2];
                    m14[2, 2] = matrica1[2, 3];
                    m15[0, 0] = matrica1[0, 0];
                    m15[0, 1] = matrica1[0, 1];
                    m15[0, 2] = matrica1[0, 3];
                    m15[1, 0] = matrica1[1, 0];
                    m15[1, 1] = matrica1[1, 1];
                    m15[1, 2] = matrica1[1, 3];
                    m15[2, 0] = matrica1[2, 0];
                    m15[2, 1] = matrica1[2, 1];
                    m15[2, 2] = matrica1[2, 3];
                    m16[0, 0] = matrica1[0, 0];
                    m16[0, 1] = matrica1[0, 1];
                    m16[0, 2] = matrica1[0, 2];
                    m16[1, 0] = matrica1[1, 0];
                    m16[1, 1] = matrica1[1, 1];
                    m16[1, 2] = matrica1[1, 2];
                    m16[2, 0] = matrica1[2, 0];
                    m16[2, 1] = matrica1[2, 1];
                    m16[2, 2] = matrica1[2, 2];
                    matrica[0, 0] = de1(m1);
                    matrica[1, 0] = -1*de1(m2);
                    matrica[2, 0] = de1(m3);
                    matrica[3, 0] = -1*de1(m4);
                    matrica[0, 1] = -1*de1(m5);
                    matrica[1, 1] = de1(m6);
                    matrica[2, 1] = -1*de1(m7);
                    matrica[3, 1] = de1(m8);
                    matrica[0, 2] = de1(m9);
                    matrica[1, 2] = -1*de1(m10);
                    matrica[2, 2] = de1(m11);
                    matrica[3, 2] = -1*de1(m12);
                    matrica[0, 3] = -1*de1(m13);
                    matrica[1, 3] = de1(m14);
                    matrica[2, 3] = -1*de1(m15);
                    matrica[3, 3] = de1(m16);
                    button9.PerformClick();
                    if (det == 0)
                    {
                        label29.Visible = true;
                    }
                    else
                    {
                        float c5 = 1 / det;
                        for (int i = 0; i < 4; i++)
                        {
                            for (int j = 0; j < 4; j++)
                            {
                                matricaRJ[i, j] = c5 * matrica[i, j];
                            }
                        }
                        label6.Visible = true;
                        label7.Visible = true;
                        label8.Visible = true;
                        label9.Visible = true;
                        label10.Visible = true;
                        label11.Visible = true;
                        label12.Visible = true;
                        label13.Visible = true;
                        label14.Visible = true;
                        label15.Visible = true;
                        label16.Visible = true;
                        label17.Visible = true;
                        label18.Visible = true;
                        label19.Visible = true;
                        label20.Visible = true;
                        label21.Visible = true;
                        label6.Text = matricaRJ[0, 0].ToString("0.00");
                        label7.Text = matricaRJ[0, 1].ToString("0.00");
                        label8.Text = matricaRJ[0, 2].ToString("0.00");
                        label9.Text = matricaRJ[0, 3].ToString("0.00");
                        label10.Text = matricaRJ[1, 0].ToString("0.00");
                        label11.Text = matricaRJ[1, 1].ToString("0.00");
                        label12.Text = matricaRJ[1, 2].ToString("0.00");
                        label13.Text = matricaRJ[1, 3].ToString("0.00");
                        label14.Text = matricaRJ[2, 0].ToString("0.00");
                        label15.Text = matricaRJ[2, 1].ToString("0.00");
                        label16.Text = matricaRJ[2, 2].ToString("0.00");
                        label17.Text = matricaRJ[2, 3].ToString("0.00");
                        label18.Text = matricaRJ[3, 0].ToString("0.00");
                        label19.Text = matricaRJ[3, 1].ToString("0.00");
                        label20.Text = matricaRJ[3, 2].ToString("0.00");
                        label21.Text = matricaRJ[3, 3].ToString("0.00");
                        label29.Visible = false;
                    }
                }
                else
                {
                    label6.Visible = false;
                    label7.Visible = false;
                    label8.Visible = false;
                    label9.Visible = false;
                    label10.Visible = false;
                    label11.Visible = false;
                    label12.Visible = false;
                    label13.Visible = false;
                    label14.Visible = false;
                    label15.Visible = false;
                    label16.Visible = false;
                    label17.Visible = false;
                    label18.Visible = false;
                    label19.Visible = false;
                    label20.Visible = false;
                    label21.Visible = false;
                }

            }
            catch
            {

            }
            
        }
        float de1(float[,] matrica1)
        {
            float a8 = 0;
            for (int i = 0; i < 3; i++)
            {
                a8 = a8 + (matrica1[0, i] * (matrica1[1, (i + 1) % 3] * matrica1[2, (i + 2) % 3] - matrica1[1, (i + 2) % 3] * matrica1[2, (i + 1) % 3]));
            }
            return a8;
        }
        float de(float[,] a8)
        {
            float m16 = a8[0, 0] * a8[1, 1], m18 = a8[0, 1] * a8[1, 0];
            return m16 - m18;
        }
        
        private void randomizirajSveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Random ran = new Random();
            if (numericUpDown5.Value == 2)
            {
                numericUpDown1.Value = ran.Next(2, 5);
                numericUpDown2.Value = ran.Next(2, 5);
                numericUpDown3.Value = ran.Next(2, 5);
                numericUpDown4.Value = ran.Next(2, 5);
                button2.PerformClick();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox6.Text = "";
                textBox7.Text = "";
                textBox8.Text = "";
                textBox9.Text = "";
                textBox10.Text = "";
                textBox11.Text = "";
                textBox12.Text = "";
                textBox13.Text = "";
                textBox14.Text = "";
                textBox15.Text = "";
                textBox16.Text = "";
                if (numericUpDown1.Value == 2 && numericUpDown2.Value == 2)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 3 && numericUpDown2.Value == 2)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox9.Text = ran.Next(min,max).ToString();
                    textBox10.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 4 && numericUpDown2.Value == 2)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox9.Text = ran.Next(min,max).ToString();
                    textBox10.Text = ran.Next(min,max).ToString();
                    textBox13.Text = ran.Next(min,max).ToString();
                    textBox14.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 2 && numericUpDown2.Value == 3)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox3.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox7.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 2 && numericUpDown2.Value == 4)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox3.Text = ran.Next(min,max).ToString();
                    textBox4.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox7.Text = ran.Next(min,max).ToString();
                    textBox8.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 3 && numericUpDown2.Value == 4)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox3.Text = ran.Next(min,max).ToString();
                    textBox4.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox7.Text = ran.Next(min,max).ToString();
                    textBox8.Text = ran.Next(min,max).ToString();
                    textBox9.Text = ran.Next(min,max).ToString();
                    textBox10.Text = ran.Next(min,max).ToString();
                    textBox11.Text = ran.Next(min,max).ToString();
                    textBox12.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 4 && numericUpDown2.Value == 3)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox3.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox7.Text = ran.Next(min,max).ToString();
                    textBox9.Text = ran.Next(min,max).ToString();
                    textBox10.Text = ran.Next(min,max).ToString();
                    textBox11.Text = ran.Next(min,max).ToString();
                    textBox13.Text = ran.Next(min,max).ToString();
                    textBox14.Text = ran.Next(min,max).ToString();
                    textBox15.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 3 && numericUpDown2.Value == 3)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox3.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox7.Text = ran.Next(min,max).ToString();
                    textBox9.Text = ran.Next(min,max).ToString();
                    textBox10.Text = ran.Next(min,max).ToString();
                    textBox11.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 4 && numericUpDown2.Value == 4)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox3.Text = ran.Next(min,max).ToString();
                    textBox4.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox7.Text = ran.Next(min,max).ToString();
                    textBox8.Text = ran.Next(min,max).ToString();
                    textBox9.Text = ran.Next(min,max).ToString();
                    textBox10.Text = ran.Next(min,max).ToString();
                    textBox11.Text = ran.Next(min,max).ToString();
                    textBox12.Text = ran.Next(min,max).ToString();
                    textBox13.Text = ran.Next(min,max).ToString();
                    textBox14.Text = ran.Next(min,max).ToString();
                    textBox15.Text = ran.Next(min,max).ToString();
                    textBox16.Text = ran.Next(min,max).ToString();
                }
                textBox17.Text = "";
                textBox18.Text = "";
                textBox19.Text = "";
                textBox20.Text = "";
                textBox21.Text = "";
                textBox22.Text = "";
                textBox23.Text = "";
                textBox24.Text = "";
                textBox25.Text = "";
                textBox26.Text = "";
                textBox27.Text = "";
                textBox28.Text = "";
                textBox29.Text = "";
                textBox30.Text = "";
                textBox31.Text = "";
                textBox32.Text = "";
                if (numericUpDown3.Value == 2 && numericUpDown4.Value == 2)
                {
                    textBox32.Text = ran.Next(min,max).ToString();
                    textBox31.Text = ran.Next(min,max).ToString();
                    textBox28.Text = ran.Next(min,max).ToString();
                    textBox27.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown3.Value == 3 && numericUpDown4.Value == 2)
                {
                    textBox32.Text = ran.Next(min,max).ToString();
                    textBox31.Text = ran.Next(min,max).ToString();
                    textBox28.Text = ran.Next(min,max).ToString();
                    textBox27.Text = ran.Next(min,max).ToString();
                    textBox24.Text = ran.Next(min,max).ToString();
                    textBox23.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown3.Value == 4 && numericUpDown4.Value == 2)
                {
                    textBox32.Text = ran.Next(min,max).ToString();
                    textBox31.Text = ran.Next(min,max).ToString();
                    textBox28.Text = ran.Next(min,max).ToString();
                    textBox27.Text = ran.Next(min,max).ToString();
                    textBox24.Text = ran.Next(min,max).ToString();
                    textBox23.Text = ran.Next(min,max).ToString();
                    textBox20.Text = ran.Next(min,max).ToString();
                    textBox19.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown3.Value == 2 && numericUpDown4.Value == 3)
                {
                    textBox32.Text = ran.Next(min,max).ToString();
                    textBox31.Text = ran.Next(min,max).ToString();
                    textBox30.Text = ran.Next(min,max).ToString();
                    textBox28.Text = ran.Next(min,max).ToString();
                    textBox27.Text = ran.Next(min,max).ToString();
                    textBox26.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown3.Value == 2 && numericUpDown4.Value == 4)
                {
                    textBox32.Text = ran.Next(min,max).ToString();
                    textBox31.Text = ran.Next(min,max).ToString();
                    textBox30.Text = ran.Next(min,max).ToString();
                    textBox29.Text = ran.Next(min,max).ToString();
                    textBox28.Text = ran.Next(min,max).ToString();
                    textBox27.Text = ran.Next(min,max).ToString();
                    textBox26.Text = ran.Next(min,max).ToString();
                    textBox25.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown3.Value == 3 && numericUpDown4.Value == 4)
                {
                    textBox32.Text = ran.Next(min,max).ToString();
                    textBox31.Text = ran.Next(min,max).ToString();
                    textBox30.Text = ran.Next(min,max).ToString();
                    textBox29.Text = ran.Next(min,max).ToString();
                    textBox28.Text = ran.Next(min,max).ToString();
                    textBox27.Text = ran.Next(min,max).ToString();
                    textBox26.Text = ran.Next(min,max).ToString();
                    textBox25.Text = ran.Next(min,max).ToString();
                    textBox24.Text = ran.Next(min,max).ToString();
                    textBox23.Text = ran.Next(min,max).ToString();
                    textBox22.Text = ran.Next(min,max).ToString();
                    textBox21.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown3.Value == 4 && numericUpDown4.Value == 3)
                {
                    textBox32.Text = ran.Next(min,max).ToString();
                    textBox31.Text = ran.Next(min,max).ToString();
                    textBox30.Text = ran.Next(min,max).ToString();
                    textBox28.Text = ran.Next(min,max).ToString();
                    textBox27.Text = ran.Next(min,max).ToString();
                    textBox26.Text = ran.Next(min,max).ToString();
                    textBox24.Text = ran.Next(min,max).ToString();
                    textBox23.Text = ran.Next(min,max).ToString();
                    textBox22.Text = ran.Next(min,max).ToString();
                    textBox20.Text = ran.Next(min,max).ToString();
                    textBox19.Text = ran.Next(min,max).ToString();
                    textBox18.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown3.Value == 3 && numericUpDown4.Value == 3)
                {
                    textBox32.Text = ran.Next(min,max).ToString();
                    textBox31.Text = ran.Next(min,max).ToString();
                    textBox30.Text = ran.Next(min,max).ToString();
                    textBox28.Text = ran.Next(min,max).ToString();
                    textBox27.Text = ran.Next(min,max).ToString();
                    textBox26.Text = ran.Next(min,max).ToString();
                    textBox24.Text = ran.Next(min,max).ToString();
                    textBox23.Text = ran.Next(min,max).ToString();
                    textBox22.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown3.Value == 4 && numericUpDown4.Value == 4)
                {
                    textBox32.Text = ran.Next(min,max).ToString();
                    textBox31.Text = ran.Next(min,max).ToString();
                    textBox30.Text = ran.Next(min,max).ToString();
                    textBox29.Text = ran.Next(min,max).ToString();
                    textBox28.Text = ran.Next(min,max).ToString();
                    textBox27.Text = ran.Next(min,max).ToString();
                    textBox26.Text = ran.Next(min,max).ToString();
                    textBox25.Text = ran.Next(min,max).ToString();
                    textBox24.Text = ran.Next(min,max).ToString();
                    textBox23.Text = ran.Next(min,max).ToString();
                    textBox22.Text = ran.Next(min,max).ToString();
                    textBox21.Text = ran.Next(min,max).ToString();
                    textBox20.Text = ran.Next(min,max).ToString();
                    textBox19.Text = ran.Next(min,max).ToString();
                    textBox18.Text = ran.Next(min,max).ToString();
                    textBox17.Text = ran.Next(min,max).ToString();
                }
            }
            else if (numericUpDown5.Value == 1)
            {
                numericUpDown1.Value = ran.Next(2, 5);
                numericUpDown2.Value = ran.Next(2, 5);
                button1.PerformClick();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox6.Text = "";
                textBox7.Text = "";
                textBox8.Text = "";
                textBox9.Text = "";
                textBox10.Text = "";
                textBox11.Text = "";
                textBox12.Text = "";
                textBox13.Text = "";
                textBox14.Text = "";
                textBox15.Text = "";
                textBox16.Text = "";
                if (numericUpDown1.Value == 2 && numericUpDown2.Value == 2)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 3 && numericUpDown2.Value == 2)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox9.Text = ran.Next(min,max).ToString();
                    textBox10.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 4 && numericUpDown2.Value == 2)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox9.Text = ran.Next(min,max).ToString();
                    textBox10.Text = ran.Next(min,max).ToString();
                    textBox13.Text = ran.Next(min,max).ToString();
                    textBox14.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 2 && numericUpDown2.Value == 3)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox3.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox7.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 2 && numericUpDown2.Value == 4)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox3.Text = ran.Next(min,max).ToString();
                    textBox4.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox7.Text = ran.Next(min,max).ToString();
                    textBox8.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 3 && numericUpDown2.Value == 4)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox3.Text = ran.Next(min,max).ToString();
                    textBox4.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox7.Text = ran.Next(min,max).ToString();
                    textBox8.Text = ran.Next(min,max).ToString();
                    textBox9.Text = ran.Next(min,max).ToString();
                    textBox10.Text = ran.Next(min,max).ToString();
                    textBox11.Text = ran.Next(min,max).ToString();
                    textBox12.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 4 && numericUpDown2.Value == 3)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox3.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox7.Text = ran.Next(min,max).ToString();
                    textBox9.Text = ran.Next(min,max).ToString();
                    textBox10.Text = ran.Next(min,max).ToString();
                    textBox11.Text = ran.Next(min,max).ToString();
                    textBox13.Text = ran.Next(min,max).ToString();
                    textBox14.Text = ran.Next(min,max).ToString();
                    textBox15.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 3 && numericUpDown2.Value == 3)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox3.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox7.Text = ran.Next(min,max).ToString();
                    textBox9.Text = ran.Next(min,max).ToString();
                    textBox10.Text = ran.Next(min,max).ToString();
                    textBox11.Text = ran.Next(min,max).ToString();
                }
                else if (numericUpDown1.Value == 4 && numericUpDown2.Value == 4)
                {
                    textBox1.Text = ran.Next(min,max).ToString();
                    textBox2.Text = ran.Next(min,max).ToString();
                    textBox3.Text = ran.Next(min,max).ToString();
                    textBox4.Text = ran.Next(min,max).ToString();
                    textBox5.Text = ran.Next(min,max).ToString();
                    textBox6.Text = ran.Next(min,max).ToString();
                    textBox7.Text = ran.Next(min,max).ToString();
                    textBox8.Text = ran.Next(min,max).ToString();
                    textBox9.Text = ran.Next(min,max).ToString();
                    textBox10.Text = ran.Next(min,max).ToString();
                    textBox11.Text = ran.Next(min,max).ToString();
                    textBox12.Text = ran.Next(min,max).ToString();
                    textBox13.Text = ran.Next(min,max).ToString();
                    textBox14.Text = ran.Next(min,max).ToString();
                    textBox15.Text = ran.Next(min,max).ToString();
                    textBox16.Text = ran.Next(min,max).ToString();
                }
            }
            else
            {
                ;
            }
        }
    }
}
